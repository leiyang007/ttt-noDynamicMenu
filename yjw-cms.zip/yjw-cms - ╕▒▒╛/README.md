# 一个使用vuejs搭建的售卖平台demo

> 一个使用vuejs搭建的售卖平台demo

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build
```
