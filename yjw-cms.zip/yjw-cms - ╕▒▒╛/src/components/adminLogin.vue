<template>
	<div class="cms-admin">
		<div v-if="isShowLogin">
			<h1 style="font-size: 50px;">CMS管理系统</h1>
			<div class="login-box">
				
				<el-form :model="ruleForm" status-icon :rules="rules2" ref="ruleForm" label-width="100px" class="demo-ruleForm">
				  <el-form-item label="用户名" prop="username">
				    <el-input type="text" v-model="ruleForm.username" @keyup.enter.native="submitForm('ruleForm')" auto-complete="off"></el-input>
				  </el-form-item>
				  <el-form-item label="密码" prop="password">
				    <el-input type="password" v-model="ruleForm.password" @keyup.enter.native="submitForm('ruleForm')" auto-complete="off"></el-input>
				  </el-form-item>
				  <el-form-item>
				    <el-button class="loginBtn123" type="primary" @click="submitForm('ruleForm')">登录</el-button>
				    <el-button @click="resetForm('ruleForm')">重置</el-button>
				  </el-form-item>
				</el-form>
			</div>			
		</div>
		<keep-alive>
	        <router-view></router-view>
	    </keep-alive>
	</div>
</template>


<script>
  export default {
    data() {
      var validatePass = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入用户名'));
        } else {
          callback();
        }
      };
      var validatePass2 = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入密码'));
        } else {
          callback();
        }
      };
      return {
      	isShowLogin: true,
      	//isShow: false,
        ruleForm: {
          username: '',
          password: ''
        },
        rules2: {
          username: [
            { validator: validatePass, trigger: 'blur' }
          ],
          password: [
            { validator: validatePass2, trigger: 'blur' }
          ]
        }
      };
    },
    methods: {
      submitForm(formName) {
      	
        this.$refs[formName].validate((valid) => {
          if (valid) {      
           	this.loginCheck()
            
          } else {
            console.log('登录失败!!');
            return false;
          }
        });
      },
      loginCheck(){
      		let _this = this
  			let parmUser = {
		  		"username": this.ruleForm.username,
    			"password": this.ruleForm.password
		  	}
  			console.log(parmUser)
  			let that = this.$axios
				let baseParmUser = this.common.DataToBase64(JSON.stringify(parmUser))
				this.$axios.post('/yjw-CMS/login?data='+baseParmUser+'&sign='+this.GLOBAL.urlStr(parmUser))
					
				  .then((res) => {				  	
				  	let nowData = JSON.parse(this.common.base64ToData(res.data))
				  	console.log(nowData)
				  	if(nowData.code == 0){	
				  		console.log(nowData.result)
				  		
					  	this.common.SStorage.setItem("saveUserInfo",nowData.result)  
					  	//document.cookie = "example=2; expires=Mon, 11 Nov 2026 07:34:46 GMT; domain=test.com;path=/"
					  	//document.cookie = 'JSESSIONID = ' + nowData.result.pwd + '; domain = www.test.com' 
					  	//document.cookie = 'JSESSIONID = ' + nowData.result.pwd
					  	//document.domain="192.168.1.2"
					  	
					  	that.defaults.headers.common['Authorization'] = nowData.result.pwd;
					  	console.log(this.common.SStorage.getItem("saveUserInfo"))
					  						  	
					  	this.$message({
				          message: nowData.message,
				          type: 'success'
				        })
					  	
					  	setTimeout(function(){
				       		_this.$router.push('/yjw_cms_system')
            				window.location.reload()
				        },700)
					  	
				  	}else{
				  		console.log(nowData.message)
				  		this.$message({
				          message: nowData.message,
				          type: 'warning'
				        })
				  	}
				  	
				  })
				  .catch((err) => {
				    console.log(err);
				    this.$message({
			          message: err,
			          type: 'warning'
			        })
				  })      	
      },
      resetForm(formName) {
        this.$refs[formName].resetFields();
      }
    },
    mounted(){
    	let nowHref = window.location.pathname
            console.log(nowHref)
            if(nowHref.indexOf('yjw_cms_system') > -1){
	  			this.isShowLogin = false
	  		}
            if(nowHref == '/'){
	  			//$('.cms-admin').css('background-color','#71CBC4')
	  			$('.cms-admin').css("background-image","url(../../static/img/cms_login_bg.jpg)");
	  			$('.cms-admin').css("background-position","center");
	  			$('.cms-admin').css("background-size","100%");
	  			$('.cms-admin').css("background-repeat","no-repeat");
	  		}
        $('.cms-admin:last-child').hide()  
        
        document.onkeydown=function(event){
			event = event|| window.event;
			if (event.keyCode == 13){
				$('.loginBtn123:first').click()
			}
		}
    }
  }
</script>

<style type="text/css">
html,body{
	height: 100%; display: block;
}	
.login-box .el-form-item__label{
	color: #fff;
}
</style>
<style scoped>	
.cms-admin{
	height: 100%; width: 100%
}		
h1{
	text-align: center; color: #fff; padding-top: 100px;
}
/*.login-box{
	width: 450px; margin: 100px auto;
}*/
.login-box{
	width: 598px; 
	height: 403px; 
	margin: 50px auto; 
	background: url(../../static/img/login-box.png) no-repeat; 
	position: relative; 
}
.demo-ruleForm{
	position: absolute; top: 110px; left: 50px; width: 67%;
}	

</style>