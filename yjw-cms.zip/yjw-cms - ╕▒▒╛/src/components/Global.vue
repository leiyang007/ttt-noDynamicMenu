
<script>
/*
 * 全局公用常量和方法
 * author by leiyang	2018.06.05
 * */
	import md5 from 'js-md5'
	import base64 from 'js-base64'
	
	//const uploadUrl = this.$axios.defaults.baseURL+'/yjw-CMS/conmonFunc/upload'		//全局配置上传地址
	
	const uploadUrl = 'http://192.168.1.2:8080/yjw-CMS/conmonFunc/upload'		//部署到公司服务器
	//const uploadUrl = 'http://116.62.241.107:8080/yjw-CMS/conmonFunc/upload'		//部署到阿里云
	//const uploadUrl = 'http://192.168.1.11:8082/yjw-CMS/conmonFunc/upload'		//郑大钊的
	
	let Base64 = require('js-base64').Base64
	let userKey = window.sessionStorage.getItem("saveUserInfo")? md5(JSON.parse(window.sessionStorage.getItem("saveUserInfo")).userkey) : null		//获取用户userKey
	let loginState = false
	let showRegister = true
	let userid = window.sessionStorage.getItem("saveUserInfo") ? JSON.parse(window.sessionStorage.getItem("saveUserInfo")).id : null		//获取用户ID
	let pageSize = 10

	console.log(userKey)
	  export default
	  {
	    userKey,  //接口访问签名
	    userid,
	    showRegister,
	    uploadUrl,
	    pageSize,
	    urlStr : (parm)=>{
	    	let	url = md5(Base64.encode(JSON.stringify(parm))+userKey)
	    	return url;
	    },
	    judgeCode: (thisCode)=>{
	    	if(thisCode == '0'){
	    		loginState = true
	    	}else{
	    		loginState = false
	    	}
	    	return loginState
	    }
	  }
</script>
