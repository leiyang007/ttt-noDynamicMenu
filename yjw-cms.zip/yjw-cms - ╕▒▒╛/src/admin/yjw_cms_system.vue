<template>
	<div class="admin-system clear">
		<div class="admin-header">
			<div class="header1">
				医界网CMS管理系统
				<!--<router-link :to="{path: '/'}">-->
					<img src="../assets/images/admin/admin-logo.png">
				<!--</router-link>-->
			</div>
			<div class="header2">
				<div class="float-left logo-admin">
					<i class="layui-icon layui-icon-home" style="font-size: 23px;"></i>
					首页
				</div>
				<div class="float-left" style="height: 100%; color: #a2a3a3;">湖北医界网电子科技有限公司</div>
				<div class="header-right-list float-right">
					<ul>
						<li>
							<i class="layui-icon layui-icon-username" style="font-size: 23px;"></i>
							{{ username }}
						</li>
						<!--<li>
							<i class="layui-icon layui-icon-notice" style="font-size: 23px;"></i>
						</li>
						<li>
							<i class="el-icon-message" style="font-size: 23px;"></i>
						</li>-->
						<!--<li>
							<router-link :to="{path: '/'}">
							<span @click="returnBack">返回官网</span>
							</router-link>
						</li>-->
						<li>
							<a href="javascript:void(0)">
								<span @click="logout">注销</span>
							</a>
						</li>
						<li>
							<a href="javascript:history.go(-1)">
								<i class="layui-icon layui-icon-return" style="font-size: 23px;"></i>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="admin-left-nav float-left">
			<el-row class="tac">			  
			  <el-col :span="12">
			    <el-menu :default-active="indexMenu" class="el-menu-vertical-demo"  background-color="#545c64" text-color="#fff" active-text-color="#ffd04b"
			    	@open="handleOpen" 
			    	@close="handleClose">
			    <router-link :to="{path: '/yjw_cms_system/userShenpiList'}">	
			      <el-menu-item index="userShenpiList">			      	
				        <i class="el-icon-menu"></i>
				        <span slot="title">企业审核</span>			        
			      </el-menu-item>
			    </router-link>  
			    <router-link :to="{path: '/yjw_cms_system/platformCompanyManage'}">	
			      <el-menu-item index="platformCompanyManage">			      	
				        <i class="el-icon-menu"></i>
				        <span slot="title">企业管理</span>			        
			      </el-menu-item>
			    </router-link> 
			    <router-link :to="{path: '/yjw_cms_system/platformGoodsManage'}">	
			      <el-menu-item index="platformGoodsManage">			      	
				        <i class="el-icon-menu"></i>
				        <span slot="title">商品管理</span>			        
			      </el-menu-item>
			    </router-link> 
			    <router-link :to="{path: '/yjw_cms_system/goodsStockManage'}">	
			      <el-menu-item index="goodsStockManage">			      	
				        <i class="el-icon-menu"></i>
				        <span slot="title">商品库存管理</span>			        
			      </el-menu-item>
			    </router-link> 
			    <router-link :to="{path: '/yjw_cms_system/businessRelationManage'}">	
			      <el-menu-item index="businessRelationManage">			      	
				        <i class="el-icon-menu"></i>
				        <span slot="title">客商关系管理</span>			        
			      </el-menu-item>
			    </router-link> 
			    <router-link :to="{path: '/yjw_cms_system/orderManage'}">	
			      <el-menu-item index="orderManage">			      	
				        <i class="el-icon-menu"></i>
				        <span slot="title">订单管理</span>			        
			      </el-menu-item>
			    </router-link>
			    <router-link :to="{path: '/yjw_cms_system/storeManage'}">	
			      <el-menu-item index="storeManage">			      	
				        <i class="el-icon-menu"></i>
				        <span slot="title">仓库管理</span>			        
			      </el-menu-item>
			    </router-link> 
			    <router-link :to="{path: '/yjw_cms_system/storageRoomManage'}">	
			      <el-menu-item index="storageRoomManage">			      	
				        <i class="el-icon-menu"></i>
				        <span slot="title">库房管理</span>			        
			      </el-menu-item>
			    </router-link> 
			    <router-link :to="{path: '/yjw_cms_system/carManage'}">	
			      <el-menu-item index="carManage">			      	
				        <i class="el-icon-menu"></i>
				        <span slot="title">车辆管理</span>			        
			      </el-menu-item>
			    </router-link> 
			    <router-link :to="{path: '/yjw_cms_system/distributorManage'}">	
			      <el-menu-item index="distributorManage">			      	
				        <i class="el-icon-menu"></i>
				        <span slot="title">配送员管理</span>			        
			      </el-menu-item>
			    </router-link> 
			    <router-link :to="{path: '/yjw_cms_system/newsManage'}">	
			      <el-menu-item index="newsManage">			      	
				        <i class="el-icon-menu"></i>
				        <span slot="title">资讯管理</span>			        
			      </el-menu-item>
			    </router-link>  		    
			      <el-submenu index="userMmanagement">
			        <template slot="title">
			          <i class="el-icon-location"></i>
			          <span>平台用户管理</span>
			        </template>
			        <el-menu-item-group>
			          <router-link :to="{path: '/yjw_cms_system/platformUserMmanage'}">
			          	<el-menu-item index="platformUserMmanage">用户管理</el-menu-item>
			          </router-link>
			          <router-link :to="{path: '/yjw_cms_system/roleAuthorityMmanage'}">
			          	<el-menu-item index="roleAuthorityMmanage">角色权限管理</el-menu-item>
			          </router-link>
			        </el-menu-item-group>
			      </el-submenu>
			    </el-menu>
			  </el-col>
			</el-row>
		</div>
		<div class="admin-right-nav" :width=rightBoxWidth ref="right_nav">
			<router-view></router-view>
		</div>
	</div>
</template>

<script>
  export default {
  	data (){
  		return {
  			indexMenu:'',
  			//leftBoxHeight: window.innerHeight-213,
  			rightBoxWidth: window.innerWidth-295,
  			username: this.common.SStorage.getItem("saveUserInfo").username
  		}
  	},
    methods: {
     returnBack(){
      	window.location.reload()
      },
      handleOpen(key, keyPath) {
        console.log(key, keyPath);
      },
      handleClose(key, keyPath) {
        console.log(key, keyPath);
      },
      logout(){
      	let _this = this
		this.common.SStorage.clear()
		//this.common.SStorage.removeItem('userKey')
      	this.$message({
          message: '注销成功!',
          type: 'success'
        })
		setTimeout(function(){
       		_this.$router.push('/')
			window.location.reload()
        },700)
      },
    },
    created (){
    	
    },
    mounted(){    	
    	
    	//设置右侧显示区域宽度自适应
    	$('.admin-right-nav').css('width',window.innerWidth-295)
    	$('.admin-left-nav').css('height',window.innerHeight-170)
    	console.log('右侧显示区宽度'+window.innerWidth-295) 
    	
    	let nowIndex = window.location.pathname
    	console.log(nowIndex.substring(16))
  		this.indexMenu = nowIndex.substring(16)
  		
  		if(nowIndex.indexOf('yjw_cms_system') > -1){
  			$('.cms-admin').css('background-color','#fff!important')
  		}
  		
  		//二级菜单页面刷新导航能正确显示
  		if(nowIndex.indexOf('userShenpiList') > -1 || nowIndex.indexOf('userShenpiInfo') > -1){
  			this.indexMenu = 'userShenpiList'
  		}else if(nowIndex.indexOf('platformCompanyManage') > -1 || nowIndex.indexOf('platformCompanyInfo') > -1){
  			this.indexMenu = 'platformCompanyManage'
  		}else if(nowIndex.indexOf('roleAuthorityMmanage') > -1 || nowIndex.indexOf('roleAuthorityMmanageUpdate') > -1){
  			this.indexMenu = 'roleAuthorityMmanage'
  		}
    }
  }	
</script>

<style scoped>
html,body{
	height: 100%;
}	
</style>

<style>
/*.cms-admin{
	background-color: #fff!important;
}*/		
.admin-system .prompt-info{	/*提示字体颜色*/
	color: #999;
}
.admin-system .el-pagination{  /*分页样式显示*/
	margin: 20px 0;
}
.admin-system .el-table .cell i:hover{
	color: deepskyblue; cursor: pointer; font-size: 18px;
}
.admin-system .el-table .cell i{
	cursor: pointer; font-size: 18px;
}
.admin-system .content-nav{
	border-bottom: 1px dashed #C9C9C9; padding-bottom: 5px; color: #909399; text-align: left; overflow: hidden;
}
.admin-system .content-nav ul li{
	float: left; margin-right: 5px;
}
/*右侧导航样式	*/
.admin-system .admin-right-nav{
	/*height: 733px;*/ margin-left: 236px; padding: 15px 20px; position: absolute; top: 170px;
}
/*右侧导航样式end	*/
	
/*左侧导航样式	*/

.admin-system .admin-left-nav{
	width: 236px; height: 733px; background-color: #545C64; position: fixed; top: 170px; z-index: 99; overflow-y: auto;
}
.admin-system .admin-left-nav .el-col-12{
	width: 100%;
}
.admin-system .admin-left-nav .el-menu{
	border-right: none; margin-bottom: 30px;
}
.admin-system .admin-left-nav .el-menu li{
	text-align: left;
}
.admin-system .admin-left-nav .el-menu-item.is-active{
	background-color: #434A50!important;
}
/*左侧导航样式end	*/
	
/*头部样式	*/
.admin-system .header1{
	min-width: 1200px; height: 120px; background-color: #28BAE6; font-size: 56px; color: #fff; line-height: 120px; position: relative;
}
.admin-system .header1 img{
	position: absolute; left: 100px; top: 20px;
}
.admin-system .header2{
	height: 50px; border-bottom: 1px solid #B1B4B5; line-height: 50px;
}
.admin-system .header2 .logo-admin{
	width: 130px; height: 100%; color: #1E9FFF;
}
.admin-system .header-right-list ul{
	height: 35px; line-height: 35px; margin-top: 8px;
}
.admin-system .header-right-list ul li{
	float: left; margin-right: 15px; padding-right: 15px; border-right: 1px solid rgba(94,94,90,0.3);
}
.admin-system .header-right-list ul li i{
	color: #1E9FFF;
}
.admin-system .header-right-list ul li:last-child{
	border-right: none;
}
.admin-system .admin-header{
	position: fixed;
    width: 100%;
    z-index: 99;
}
.admin-system .admin-header .header2{
	background-color: #fff;
}
/*头部样式end	*/


/*全局样式*/
*{padding:0;margin:0;}
div,dl,dt,dd,form,h1,h2,h3,h4,h5,h6,img,ol,ul,li,table,th,td,p,span,a{border:0px solid red;}
img,input{border:none; vertical-align:middle; outline:medium;}
body{font-family:微软雅黑; font-size:16px; text-align:center; background:#fff;}
html{overflow-y:auto;}
ul li{list-style-type:none;}
a{text-decoration:none; color:#333;}
a:hover{text-decoration:none; color: #1BB1FE;}
textarea{resize:none;}

.layui-form-item input::-webkit-input-placeholder,.layui-form-item textarea::-webkit-input-placeholder{ /*WebKit browsers*/
	color: #c2bfbf;	
}
.layui-form-item input::-moz-input-placeholder,.layui-form-item textarea::-moz-input-placeholder{ /*Mozilla Firefox*/
	color: #c2bfbf;	
}
.layui-form-item input::-ms-input-placeholder,.layui-form-item textarea::-ms-input-placeholder{ /*Internet Explorer*/ 
	color: #c2bfbf;	
}
input::-webkit-input-placeholder,.layui-form-item textarea::-webkit-input-placeholder{ /*WebKit browsers*/
	color: #c2bfbf;	
}
input::-moz-input-placeholder,.layui-form-item textarea::-moz-input-placeholder{ /*Mozilla Firefox*/
	color: #c2bfbf;	
}
input::-ms-input-placeholder,.layui-form-item textarea::-ms-input-placeholder{ /*Internet Explorer*/ 
	color: #c2bfbf;	
}
.float-left{float:left;}
.float-right{float:right;}
.clear{overflow: hidden;}
.pointer{cursor: pointer;}
.red-font{color: red;}
.blue-font{color: #00BFFF;}
.gray-font{color: gray;}
.yellow-font{color: #E6A23C;}

.font-22{font-size: 22px;}
.font-20{font-size: 20px;}
.font-18{font-size: 18px;}
.font-16{font-size: 16px;}
.font-13{font-size: 13px;}
.font-12{font-size: 12px;}
.font-10{font-size: 10px;}
.font-weight{font-weight: bold;}

.line-1{
	overflow:hidden; 
	text-overflow:ellipsis;	
	display:-webkit-box; 	
	/* autoprefixer: off */  
  -webkit-box-orient: vertical;  
  /* autoprefixer: on */
 -webkit-line-clamp:1;	
}
.line-2{
	overflow:hidden; 
	text-overflow:ellipsis;	
	display:-webkit-box; 	
	/* autoprefixer: off */  
  -webkit-box-orient: vertical;  
  /* autoprefixer: on */	
	-webkit-line-clamp:2; 
}
.line-3{
	overflow:hidden; 
	text-overflow:ellipsis;	
	display:-webkit-box; 	
	/* autoprefixer: off */  
  -webkit-box-orient: vertical;  
  /* autoprefixer: on */	
	-webkit-line-clamp:3; 
}

.anchorBL,.BMap_noprint{display:none;} 

</style>