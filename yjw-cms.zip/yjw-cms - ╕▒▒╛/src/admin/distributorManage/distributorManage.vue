<template>
	<div class="distributor-add-goods">
		<div class="table-head clear">
			<ul class="clear">
				<li>	
					<div class="demo-input-suffix">
					  <el-input v-model="searchText" placeholder="搜索姓名/注册公司" style="width: 300px;"></el-input>
					</div>
				</li>
				<li>
					<el-button type="primary" @click="checkBut(1)">查询</el-button>			
				</li>
			</ul> 
		</div>
		<div class="table-body">
			<template>
			  <el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%;text-align: left;">			    
			    <el-table-column prop="driverId" label="配送员编号">
			    </el-table-column>
			    <el-table-column prop="name" label="姓名">
			    </el-table-column>
			    <el-table-column prop="sexString" label="性别">
			    </el-table-column>		    
			    <el-table-column prop="phone" label="联系方式">
			    </el-table-column>	
			    <el-table-column prop="companyName" label="注册公司">
			    </el-table-column>			    	    
			  </el-table>
			    <el-pagination
			      @size-change="handleSizeChange"
			      @current-change="handleCurrentChange"
			      :current-page.sync="nowPage"
			      :page-size="pageSize"
			      layout="prev, pager, next, jumper"
			      :total="totalCount">
			    </el-pagination>
			</template>				
		</div>		
	</div>
</template>

<script>
export default{
	data(){
		return{
			userType: null,			//用户类型,如:厂家\经销商等
			nowPage: 1,				//当前页
	      	pageSize: this.GLOBAL.pageSize,			//每页显示条数
	      	totalCount: 0,			//总条数
			searchText: '',		   
			tableData: []
		}
	},	
	methods:{			
		checkBut(type){
			this.getTableData(type)
		},		
		getTableData(type){
			let _this = this
    		let parm = {
					 	 "selectStr": this.searchText,
						   "pageNum": type? type : this.nowPage,
						  "pageSize": this.pageSize,
			     			"signId": this.GLOBAL.userid
	    			}  

				let baseParm = _this.common.DataToBase64(JSON.stringify(parm))
				console.log(parm)
					
			_this.$axios.post('/yjw-CMS/wms/selectForDriverManage?data='+baseParm+'&sign='+_this.GLOBAL.urlStr(parm))
			  .then((res) => {
			  	
			  	let nowData = JSON.parse(_this.common.base64ToData(res.data))
				console.log(JSON.stringify(nowData.result))
			  	if(nowData.code == 0){		
			  		this.tableData = nowData.result.list
			  		this.totalCount = nowData.result.total
			  		console.log(JSON.stringify(this.tableData))
			  		this.$message({
			          message: nowData.message,
			          type: 'success'
			        })
			  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
			  		console.log(nowData.message)
			  		this.$message({
			          message: nowData.message,
			          type: 'warning'
			        })
			  	}		  			
			  })
			  .catch((err) => {
			    console.log(err);
			    this.$message({
		          message: err,
		          type: 'warning'
		        })
			  })
		},
 		handleSizeChange(val){
    		this.pageSize = val
    		console.log(this.pageSize)
    	},
    	handleCurrentChange(val){
    		this.nowPage = val
    		console.log('当前页是:'+this.nowPage)
    		this.getTableData()
    	}	 
		
	},
	mounted (){
		this.getTableData()	
		
		this.userType = this.common.SStorage.getItem("saveUserInfo").userType 
	}	
}
</script>

<style scoped>
.table-head{
	padding: 10px 0; border-bottom: 1px solid #DCDFE6;	
}
.table-head ul li{
	float: left; margin: 0 20px 10px 0;
}	

</style>