<template>
	<div class="distributor-add-goods">
		<div class="table-head clear">
			<ul class="clear">
				<li>	
					<div class="demo-input-suffix">
					  <el-input v-model="ckmcText" placeholder="输入仓库名称" style="width: 200px;"></el-input>
					</div>
				</li>
				<li>	
					<div class="demo-input-suffix">
						仓库地址:
					  <el-select v-model="province" placeholder="省" @change="provChange">
					    <el-option
					      v-for="item in provinceList"
					      :key="item.code"
					      :label="item.fullName"
					      :value="item.code">
					    </el-option>
					  </el-select> 
					  <el-select v-model="city" placeholder="市" @change="cityChange">
					    <el-option
					      v-for="item in cityList"
					      :key="item.code"
					      :label="item.fullName"
					      :value="item.code">
					    </el-option>
					  </el-select> 
					  <el-select v-model="area" placeholder="区" @change="areaChange">
					    <el-option
					      v-for="item in areaList"
					      :key="item.code"
					      :label="item.fullName"
					      :value="item.code">
					    </el-option>
					  </el-select> 
					</div>
				</li>
				<li>
					<el-button type="primary" @click="checkBut(1)">查询</el-button>			
				</li>
				<li>
					<el-button type="info" @click="reset">重置</el-button>			
				</li>
			</ul> 
		</div>
		<div class="table-body">
			<template>
			  <el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%;text-align: left;">			    
			    <el-table-column prop="sn" label="仓库编号">
			    </el-table-column>
			    <el-table-column prop="name" label="仓库名称">
			    </el-table-column>
			    <el-table-column prop="typeString" label="仓库类型">
			    </el-table-column>
			    <el-table-column prop="address" label="仓库地址">
			    </el-table-column>
			    <el-table-column prop="companyName" label="所属公司">
			    </el-table-column>			    	    
			  </el-table>
			    <el-pagination
			      @size-change="handleSizeChange"
			      @current-change="handleCurrentChange"
			      :current-page.sync="nowPage"
			      :page-size="pageSize"
			      layout="prev, pager, next, jumper"
			      :total="totalCount">
			    </el-pagination>
			</template>				
		</div>		
	</div>
</template>

<script>
export default{
	data(){
		return{
			nowPage: 1,				//当前页
	      	pageSize: this.GLOBAL.pageSize,			//每页显示条数
	      	totalCount: 0,			//总条数
			ckmcText: '',		   //仓库名称
			province: null,		//省编号
      	 	city: null,			//市编号
      	 	area: '',				//区编号
      	 	provinceList: [],      //省列表 	 
      	 	cityList: [],      	//市列表 
      	 	areaList: [],      	 //区列表
			tableData: []
		}
	},	
	methods:{		
		reset(){
			this.ckmcText = ''
			this.province = null
			this.city = null
			this.area = null
		},	
		checkBut(type){
			this.getTableData(type)
		},		
		getTableData(type){
			let _this = this
    		let parm = {
    					      "name": this.ckmcText,
    				   "regionCode1": this.province,
					   "regionCode2": this.city,
					   "regionCode3": this.area,
						   "pageNum": type? type : this.nowPage,
						  "pageSize": this.pageSize,
			     			"signId": this.GLOBAL.userid
	    			}  

				let baseParm = _this.common.DataToBase64(JSON.stringify(parm))
				console.log(parm)
					
			_this.$axios.post('/yjw-CMS/wms/selectForRepertoryManage?data='+baseParm+'&sign='+_this.GLOBAL.urlStr(parm))
			  .then((res) => {
			  	
			  	let nowData = JSON.parse(_this.common.base64ToData(res.data))
				console.log(JSON.stringify(nowData.result))
			  	if(nowData.code == 0){		
			  		this.tableData = nowData.result.list
			  		this.totalCount = nowData.result.total
			  		console.log(JSON.stringify(this.tableData))
			  		this.$message({
			          message: nowData.message,
			          type: 'success'
			        })
			  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
			  		console.log(nowData.message)
			  		this.$message({
			          message: nowData.message,
			          type: 'warning'
			        })
			  	}		  			
			  })
			  .catch((err) => {
			    console.log(err);
			    this.$message({
		          message: err,
		          type: 'warning'
		        })
			  })
		},
 		handleSizeChange(val){
    		this.pageSize = val
    		console.log(this.pageSize)
    	},
    	handleCurrentChange(val){
    		this.nowPage = val
    		console.log('当前页是:'+this.nowPage)
    		this.getTableData()
    	},	 
    	prov_city_area(){
				let _this = this
				
			//初步加载省级数据
				let parm = {
			  		'type':1,
			  		'parentCode':100000
			  	}
				let baseParm = _this.common.DataToBase64(JSON.stringify(parm))
				console.log(baseParm)
					
			_this.$axios.get('/wms_web/regionSelect?data='+baseParm+'&sign='+_this.GLOBAL.urlStr(parm))
			  .then((res) => {
			  	
			  	let nowData = JSON.parse(_this.common.base64ToData(res.data))
	
			  	if(nowData.code == 0){		
			  		_this.provinceList = nowData.result.data
			  		console.log(JSON.stringify(_this.provinceList))
			  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
			  		console.log(nowData.message)
			  	}		  			
			  })
			  .catch((err) => {
			    console.log(err);
			  })
			//初步加载省级数据end	
		},
		provChange (data){
			console.log('省级编号:'+data)
			this.city = null	//每次选择省级清空市和区
			this.area = null	//同上
			let _this = this
			//加载市级数据	
			  let parm = {
			  		'type':2,
			  		'parentCode':data
			  	}
				let baseParm = _this.common.DataToBase64(JSON.stringify(parm))
				console.log(parm)
					
				_this.$axios.get('/wms_web/regionSelect?data='+baseParm+'&sign='+_this.GLOBAL.urlStr(parm))
				  .then((res) => {
				  	
				  	let nowData = JSON.parse(_this.common.base64ToData(res.data))

				  	if(nowData.code == 0){		
				  		_this.cityList = nowData.result.data
				  		console.log(JSON.stringify(_this.cityList))
				  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
				  		console.log(nowData.message)
				  	}		  			
				  })
				  .catch((err) => {
				    console.log(err);
				  })
				//加载市级数据end  
		},
		cityChange (data){
			console.log('市级编号:'+data)
			this.area = null	//每次选择市清空区
			
			let _this = this
			//加载区级数据	
			  let parm = {
			  		'type':3,
			  		'parentCode':data
			  	}
				let baseParm = _this.common.DataToBase64(JSON.stringify(parm))
				console.log(parm)
					
				_this.$axios.get('/wms_web/regionSelect?data='+baseParm+'&sign='+_this.GLOBAL.urlStr(parm))
				  .then((res) => {
				  	
				  	let nowData = JSON.parse(_this.common.base64ToData(res.data))

				  	if(nowData.code == 0){		
				  		_this.areaList = nowData.result.data
				  		console.log(JSON.stringify(_this.areaList))
				  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
				  		console.log(nowData.message)
				  	}		  			
				  })
				  .catch((err) => {
				    console.log(err);
				  })
				//加载区级数据end  
		},
		areaChange (data){
			this.area = data
			console.log('地区编号:'+data)
		}
	},
	mounted (){
		this.getTableData()	
		this.prov_city_area()	//加载省市联动数据
	}	
}
</script>

<style scoped>
.table-head{
	padding: 10px 0; border-bottom: 1px solid #DCDFE6;	
}
.table-head ul li{
	float: left; margin: 0 20px 10px 0;
}	

</style>