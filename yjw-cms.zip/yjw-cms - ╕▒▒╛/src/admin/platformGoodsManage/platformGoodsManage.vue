<template>
	<div class="distributor-add-goods">
		<div class="table-head clear">
			<ul class="clear">
				<li>	
					<div class="demo-input-suffix">
						商品名称:
					  <el-input v-model="goodsText" placeholder="查商品名称" style="width: 120px;"></el-input>
					</div>
				</li>
				<li>	
					<div class="demo-input-suffix">
						生产厂家:
					  <el-input v-model="companyText" placeholder="查生产厂家" style="width: 120px;"></el-input>
					</div>
				</li>
				<li>	
					<div class="demo-input-suffix">
						商品类别:
					    <el-select v-model="goodsCategory" placeholder="请选择" @change="getGoodsCategory" style="width: 100px;">
						    <el-option
						      v-for="item in goodsList"
						      :key="item.name"
						      :label="item.name"
						      :value="item.name">
						    </el-option>
						</el-select> 
					</div>
				</li>
				<li>	
					<div class="demo-input-suffix">
						商品类型:
					    <el-select v-model="goodsType" placeholder="请选择" @change="getGoodsType" style="width: 150px;">
						    <el-option
						      v-for="item in goodsTypeList"
						      :key="item.classCode"
						      :label="item.name"
						      :value="item.classCode">
						    </el-option>
						</el-select> 
					</div>
				</li>
				<li>	
					<div class="demo-input-suffix">
						所属分类目录:
					    <el-select v-model="ownClassMenu" placeholder="请选择" @change="getClassMenu" style="width: 150px;">
						    <el-option
						      v-for="item in menuList"
						      :key="item.classCode"
						      :label="item.name"
						      :value="item.classCode">
						    </el-option>
						</el-select> 
					</div>
				</li>
				<li>
					<el-button type="primary" @click="checkBut(1)">查询</el-button>			
				</li>
				<li>
					<el-button type="info" @click="reset">重置</el-button>			
				</li>
			</ul> 
		</div>
		<div class="table-body">
			<template>
			  <el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%;text-align: left;">			    
			    <el-table-column prop="productSn" label="商品编号">
			    </el-table-column>
			    <el-table-column prop="name" label="商品名称" width="200px">
			    </el-table-column>
			    <el-table-column prop="attribute" label="商品类别">
			    </el-table-column>
			    <el-table-column prop="className" label="所属分类目录" width="200px">
			    </el-table-column>
			    <el-table-column prop="packing" label="规格型号">
			    </el-table-column>
			    <el-table-column prop="unit" label="计量单位">
			    </el-table-column>
			    <el-table-column prop="registrationNumber" label="注册证号" width="200px">
			    </el-table-column>
			    <el-table-column prop="factoryName" label="生产厂家" width="200px">
			    </el-table-column>
			    <el-table-column prop="licenseNumber" label="生产企业许可证号" width="200px">
			    </el-table-column>
			    <el-table-column prop="expiryDate" label="有效期(月)">
			    </el-table-column>
			    <el-table-column prop="temperature" label="存储温度">
			    </el-table-column>
			    <el-table-column prop="humidity" label="存储湿度">
			    </el-table-column>		    
			  </el-table>
			    <el-pagination
			      @size-change="handleSizeChange"
			      @current-change="handleCurrentChange"
			      :current-page.sync="nowPage"
			      :page-size="pageSize"
			      layout="prev, pager, next, jumper"
			      :total="totalCount">
			    </el-pagination>
			</template>				
		</div>		
	</div>
</template>

<script>
export default{
	data(){
		return{
			userType: null,			//用户类型,如:厂家\经销商等
			nowPage: 1,				//当前页
	      	pageSize: this.GLOBAL.pageSize,			//每页显示条数
	      	totalCount: 0,			//总条数
			goodsText: '',		   //搜索内容
			companyText: '',		//搜索内容
			goodsCategory: null,
			goodsType: null,
			ownClassMenu: null,
			goodsList: [
				{
					value: 0,
					name: 'Ⅰ'
				},
				{
					value: 1,
					name: 'Ⅱ'
				},
				{
					value: 2,
					name: 'Ⅲ'
				}
			],
			goodsTypeList: [],
			menuList: [],
			tableData: [],
			form: {
				factory: ''
			},
			factoryList: [],
			goodsInput: '',
			gridData: []				//新增查询表格数据
		}
	},	
	methods:{	
		reset(){
			this.goodsText = ''
			this.companyText = ''
			this.goodsCategory = null
			this.goodsType = null
			this.ownClassMenu = null
		},			
		checkBut(type){
			this.getTableData(type)
		},		
		queryFactoryTableData(){
			let arr = [this.form.factory]
			let parm = {
		  		     	 "nameOrsn": this.goodsInput,
					    "companyId": arr,
    				       "signId": this.GLOBAL.userid
		  			}
  			console.log(JSON.stringify(parm))
				let baseparm = this.common.DataToBase64(JSON.stringify(parm))
				this.$axios.post('/product-web/product/selectFactoryGoodsForDealer?data='+baseparm+'&sign='+this.GLOBAL.urlStr(parm))
					
			  .then((res) => {				  	
			  	let nowData = JSON.parse(this.common.base64ToData(res.data))
			  	if(nowData.code == 0){	
			  		console.log(JSON.stringify(nowData.result))
			  		this.gridData = nowData.result
			  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
			  		console.log(nowData.message)
			  		this.$message({
			          message: nowData.message,
			          type: 'warning'
			        })
			  	}
			  	
			  })
			  .catch((err) => {
			    console.log(err);
			    this.$message({
		          message: err,
		          type: 'warning'
		        })
			  })			
		},
		goodsQuery(){
			this.queryFactoryTableData()			
		},
		getGoodsCategory(val){
			console.log(val)
		},
		getGoodsType(val){
			console.log(val)
			this.getGoodsMenu(val)    //加载商品类别
			this.ownClassMenu = ''
		},
		getClassMenu(val){
			console.log(val)
		},
		getTableData(type){
			let _this = this
    		let parm = {
					   "factoryName": this.companyText,
    					  "nameOrsn": this.goodsText,
    					 "className": this.ownClassMenu ? this.ownClassMenu : this.goodsType,
						 "attribute": this.goodsCategory,
						   "pageNum": type? type : this.nowPage,
						  "pageSize": this.pageSize,
			     			"signId": this.GLOBAL.userid
	    			}  

				let baseParm = _this.common.DataToBase64(JSON.stringify(parm))
				console.log(parm)
					
			_this.$axios.post('/yjw-CMS/product/getFactoryGoods?data='+baseParm+'&sign='+_this.GLOBAL.urlStr(parm),)
			  .then((res) => {
			  	
			  	let nowData = JSON.parse(_this.common.base64ToData(res.data))
				console.log(JSON.stringify(nowData.result))
			  	if(nowData.code == 0){		
			  		this.tableData = nowData.result.list
			  		this.totalCount = nowData.result.total
			  		console.log(JSON.stringify(this.tableData))
			  		this.$message({
			          message: nowData.message,
			          type: 'success'
			        })
			  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
			  		console.log(nowData.message)
			  		this.tableData = []
			  		this.$message({
			          message: nowData.message,
			          type: 'warning'
			        })
			  	}		  			
			  })
			  .catch((err) => {
			    console.log(err);
			    this.tableData = []
			    this.$message({
		          message: err,
		          type: 'warning'
		        })
			  })
		},
 		handleSizeChange(val){
    		this.pageSize = val
    		console.log(this.pageSize)
    	},
    	handleCurrentChange(val){
    		this.nowPage = val
    		console.log('当前页是:'+this.nowPage)
    		this.getTableData()
    	}, 		 
		getGoodsMenu(vid){		//查询商品分类
			let _this = this
			let parm =  {
							  "type": 1,
						    "signId": this.GLOBAL.userid
				    	}

  			console.log(JSON.stringify(parm))
				let baseparm = this.common.DataToBase64(JSON.stringify(parm))
				this.$axios.post('/yjw-CMS/product/getProductClass?data='+baseparm+'&sign='+this.GLOBAL.urlStr(parm))
					
			  .then((res) => {				  	
			  	let nowData = JSON.parse(this.common.base64ToData(res.data))
			  	console.log(JSON.stringify(nowData))
			  	if(nowData.code == 0){	
			  		console.log(JSON.stringify(nowData.result))
			  		_this.goodsTypeList = nowData.result[0].parent
			  		
			  		if(vid == 1){
			  			_this.menuList = nowData.result[0].drug
			  		}else{
			  			_this.menuList = nowData.result[0].inss
			  		}
			  		console.log(JSON.stringify(_this.menuList))
			  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
			  		console.log(nowData.message)
			  		this.$message({
			          message: nowData.message,
			          type: 'warning'
			        })
			  	}
			  	
			  })
			  .catch((err) => {
			    console.log(err);
			    this.$message({
		          message: err,
		          type: 'warning'
		        })
			  })
		}
	},
	mounted (){
		this.getGoodsMenu()
		this.getTableData()	
		
		this.userType = this.common.SStorage.getItem("saveUserInfo").userType 
	}	
}
</script>

<style scoped>
.table-head{
	padding: 10px 0; border-bottom: 1px solid #DCDFE6;	
}
.table-head ul li{
	float: left; margin: 0 20px 10px 0;
}

</style>