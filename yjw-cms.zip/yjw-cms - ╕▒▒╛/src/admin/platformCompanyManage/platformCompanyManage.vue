<template>
	<div class="shenpi-list">
		<div class="float-left">
			<ul class="shenpi-list-ul clear">
				<li>
					<el-input
					    placeholder="请输入企业名称"
					    prefix-icon="el-icon-search"
					    v-model="hzdw_val">
					  </el-input>
				</li>
				<li>
					<el-button type="primary" @click="checkBut(1)">查询</el-button>
				</li>
			</ul> 
		</div>
		<div>
			<el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%;text-align: left;">			    			    
			    <el-table-column prop="taskName" label="审批人">
			    </el-table-column>
			    <el-table-column prop="sn" label="企业编号">
			    </el-table-column>
			    <el-table-column prop="companyName" label="企业名称">
			    </el-table-column>
			    <el-table-column prop="taxpayerRegistrationNumber" label="纳税人识别号">
			    </el-table-column>
			    <el-table-column prop="legalPerson" label="法人">
			    </el-table-column>
			    <el-table-column prop="companyType" :formatter="companyTypeFormat" label="企业类型">
			    </el-table-column>
			    <el-table-column prop="registeredCapital" label="注册资金">
			    </el-table-column>
			    <el-table-column prop="location" label="地址">
			    </el-table-column>
			    <el-table-column prop="contactPerson1" label="联系人">
			    </el-table-column>
			    <el-table-column prop="phone1" label="联系方式">
			    </el-table-column>
			    <el-table-column prop="" label="操作">
			    	<template slot-scope="scope">
			    		<router-link :to="{path: '/yjw_cms_system/platformCompanyInfo',query:{
			    						id: scope.row.id,
			    			   companyType: scope.row.companyType,
			    			   		status: scope.row.status
			    			}}">
			    			<i class="el-icon-search" title="查看"></i>	
			    		</router-link>
			    		<i class="el-icon-error" style="margin-left: 10px;" @click="jinfeng(scope.row,0)" v-show="scope.row.sta == 1" title="启用"></i>				    		
			    		<i class="el-icon-success" style="margin-left: 10px;" @click="jinfeng(scope.row,1)" v-show="scope.row.sta == 0" title="禁用"></i>				    		
			    	</template>
			    </el-table-column>	
			</el-table>
			<el-pagination
		      @size-change="handleSizeChange"
		      @current-change="handleCurrentChange"
		      :current-page.sync="nowPage"
		      :page-size="pageSize"
		      layout="prev, pager, next, jumper"
		      :total="totalCount">
		    </el-pagination>
		</div>
	</div>
</template>

<script>
  export default {
  	data (){
  		return {
  			nowPage: 1,								//当前页
	      	pageSize: this.GLOBAL.pageSize,			//每页显示条数
	      	totalCount: 0,							//总条数
  			tableData: [],
  			hzdw_val: null
  		}
  	},
    methods: {
    	jinfeng(row,type){
  			let parm = {
		  		  "userId": this.common.SStorage.getItem("saveUserInfo").id,
		  	 	  "status": type,
		  		 	  "sn": row.sn,
		  		  "signId": this.GLOBAL.userid
		  	}
  			console.log(parm)
				let baseParmUser = this.common.DataToBase64(JSON.stringify(parm))
				this.$axios.post('/yjw-CMS/company/updateCompany?data='+baseParmUser+'&sign='+this.GLOBAL.urlStr(parm))
					
				  .then((res) => {				  	
				  	let nowData = JSON.parse(this.common.base64ToData(res.data))
				  	console.log(nowData)
				  	if(nowData.code == 0){	
				  		console.log(JSON.stringify(nowData.result))
				  		if(type == 0){
				  			this.$message({
					          message: "启用成功!",
					          type: 'success'
					        })
				  		}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
				  			this.$message({
					          message: "禁用成功!",
					          type: 'success'
					        })
				  		}
					  	
					  this.queryData()	
				  	}else{
				  		console.log(nowData.message)
				  		this.$message({
				          message: nowData.message,
				          type: 'warning'
				        })
				  	}
				  	
				  })
				  .catch((err) => {
				    console.log(err);
				    this.$message({
			          message: err,
			          type: 'warning'
			        })
				  })
    	},
    	companyTypeFormat(val){
    		if(val.companyType == 0){
    			return '医疗机构'
    		}else if(val.companyType == 1){
    			return '经销商'
    		}else if(val.companyType == 2){
    			return '生产厂家'
    		}else if(val.companyType == 3){
    			return '监管机构'
    		}
    	},
    	regMoney(val){
    		return val.registeredCapital + '万元'
    	},
    	shType(val){    		
    		if(val.status == '0'){
    			return '审核通过'
    		}else if(val.status == '1'){
    			return '审核未通过'
    		}else{
    			return '待审核'
    		}
    	},
     	checkBut(page){
     		this.queryData(page)
     	},
     	queryData(page){
  			let parm = {
		  		  "userId": this.common.SStorage.getItem("saveUserInfo").id,
		  	 "companyName": this.hzdw_val,
		  		 "pageNum": page ? page : this.nowPage,
				"pageSize": this.pageSize,
		  		  "signId": this.GLOBAL.userid
		  	}
  			console.log(parm)
				let baseParmUser = this.common.DataToBase64(JSON.stringify(parm))
				this.$axios.post('/yjw-CMS/company/getTask?data='+baseParmUser+'&sign='+this.GLOBAL.urlStr(parm))
					
				  .then((res) => {				  	
				  	let nowData = JSON.parse(this.common.base64ToData(res.data))
				  	console.log(nowData)
				  	if(nowData.code == 0){	
				  		console.log(JSON.stringify(nowData.result))
				  		this.tableData = nowData.result.list
				  		this.totalCount = nowData.result.total
				  		
					  	this.$message({
				          message: nowData.message,
				          type: 'success'
				        })					  	
					  	
				  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
				  		console.log(nowData.message)
				  		this.$message({
				          message: nowData.message,
				          type: 'warning'
				        })
				  	}
				  	
				  })
				  .catch((err) => {
				    console.log(err);
				    this.$message({
			          message: err,
			          type: 'warning'
			        })
				  })       		
     	},
    	handleSizeChange(val){
    		this.pageSize = val
    		console.log(this.pageSize)
    	},
    	handleCurrentChange(val){
    		this.nowPage = val
    		console.log('当前页是:'+this.nowPage)
    		this.queryData()
    	}     	
    },
    created (){
    	
    },
    mounted(){
    	this.queryData()
    }
  }		
</script>

<style scoped>

.shenpi-list-ul li{
	float: left; margin-right: 10px;
}
.page-title{
	border-bottom: 1px solid #999; text-align: left; padding: 10px 0; position: relative;
}	
	
</style>