<template>
	<div class="">
		<div class="content-nav">
			<ul>
				<li>
					<a href="javascript:history.go(-1)">返回上一步</a>
				</li>
				<li><i class="el-icon-arrow-right"></i></li>
				<li class="blue-font">平台资讯新增</li>
			</ul>
		</div>
		<div class="page-title clear">
			<div class="float-left font-20">平台资讯新增</div>
			<div class="float-right">
				<el-button type="warning" @click="saveDate">保存</el-button>
				<el-button type="warning" @click="issueLine" :disabled="articleId == null? true : false">发布</el-button>
			</div>
		</div>
		<div class="page-body">
			<el-form ref="form" :model="form" label-width="80px">
			  <el-form-item label="标题:" style="width:500px">
			    <el-input v-model="form.title"></el-input>
			  </el-form-item>
			  <el-form-item label="栏目:" style="width:280px">
			    <el-select v-model="form.menu" placeholder="请选择栏目" @change="lanmuChange">
			      	<el-option
				      v-for="item in lanmuList"
				      :key="item.id"
				      :label="item.name"
				      :value="item.id">
				    </el-option>
			    </el-select>
			  </el-form-item>
			  <el-form-item label="政策日期:" style="width:280px; position: relative;">
			      <el-date-picker type="date" placeholder="选择日期" v-model="form.date" style="width: 100%;"></el-date-picker>
			      <el-checkbox style="position: absolute; top: 0px; left: 240px;" v-model="form.checked">发布到首页</el-checkbox>
			  </el-form-item>
			  <el-form-item label="简介:" style="width:500px">
				    <el-input
					  type="textarea"
					  :rows="3"
					  placeholder="请输入内容"
					  v-model="form.introduction">
					</el-input>
			  </el-form-item>
			  <el-form-item label="标题图片:">
			    	<div class="float-left">
						<el-upload
						  class="avatar-uploader"
						  :action="reqUrl"
						  :show-file-list="false"
						  :on-success="handleAvatarSuccess"
						  :before-upload="beforeAvatarUpload"
						  :on-change="checkImg">
						  <img v-if="imageUrl" :src="imageUrl" class="avatar">
						  <i v-else class="el-icon-plus avatar-uploader-icon"></i>
						</el-upload>
						<span class="blue-font font-13">文件上传 支持jpg、png等</span>
						<span class="red-font font-13" v-show="noImage">请选择文件</span>
					</div>
			  </el-form-item>
			</el-form>
		</div>	
		<div>
			<!--<button @click="getUEContent()">获取内容</button>-->
			<UE :defaultMsg=defaultMsg :config=config ref="ue"></UE>
		</div>
		
	</div>
</template>

<script>
import UE from '../admin-base/ueditor.vue'

  export default {
  	components: {
  		UE
  	},
  	data (){
  		return {
  			reqUrl: this.GLOBAL.uploadUrl,
  			imageUrl: '',
  			form: {
  				title: null,
  				menu: null,
  				date: null,
  				checked: true,
  				introduction: ''  				
  			},
  			lanmuList: [		//栏目列表
      	 		{
      	 			id: 1,
      	 			name: '新闻资讯'
      	 		},
      	 		{
      	 			id: 2,
      	 			name: '平台通知'
      	 		},
      	 		{
      	 			id: 3,
      	 			name: '产品召回'
      	 		},
      	 		{
      	 			id: 4,
      	 			name: '曝光栏'
      	 		},
      	 	],  
  			defaultMsg: '',
	        config: {
	          initialFrameWidth: null,
	          initialFrameHeight: 350
	        },
	        articleId: null
	  	}
  	},
    methods: {
    	getUEContent() {
	        let content = this.$refs.ue.getUEContent();
	        /*this.$notify({
	          title: '获取成功，可在控制台查看！',
	          message: content,
	          type: 'success'
	        });*/
	        return content
	        /*this.defaultMsg = content
	        console.log(this.defaultMsg)*/
	    },
	    lanmuChange(val){
			console.log(val)
		},
	    checkImg(file, fileList){
	      	if(fileList.length != 0){
	      		this.noImage = false
	      	}
	    }, 
		handleAvatarSuccess(res, file) {					//-----------上传单文件			
	        //this.imageUrl = URL.createObjectURL(file.raw);
	        this.imageUrl = res;
	        console.log(this.imageUrl)
	   },
	    beforeAvatarUpload(file) {
	        const isJPG = file.type === 'image/jpeg' || file.type === 'image/png';
	        const isLt5M = file.size / 1024 / 1024 < 5;
	
	        if (!isJPG) {
	          this.$message.error('上传头像图片只能是 JPG/PNG 格式!');
	        }
	        if (!isLt5M) {
	          this.$message.error('上传头像图片大小不能超过 5MB!');
	        }
	        return isJPG && isLt5M;
	    },
	    issueLine(row){			//发布
	    	let _this = this
			this.$confirm('确定要发布吗?', '提示', {
	          confirmButtonText: '确定',
	          cancelButtonText: '取消',
	          type: 'warning'
	        }).then(() => {
	  			    let parm = {
						        "id": this.articleId,
						    "status": 1,
						      "type": 1,
						    "issued": this.form.checked == true? 0 : 1,
						   "updater": this.common.SStorage.getItem('saveUserInfo').id,
			     			"signId": this.GLOBAL.userid
	    			}  

				let baseParm = this.common.DataToBase64(JSON.stringify(parm))
				console.log(parm)
						
				this.$axios.post('/yjw-CMS/article/update?data='+baseParm+'&sign='+this.GLOBAL.urlStr(parm))
				  .then((res) => {
				  	
				  	let nowData = JSON.parse(this.common.base64ToData(res.data))
					console.log(JSON.stringify(nowData.result))
				  	if(nowData.code == 0){				  		
				  		this.$message({
				          message: nowData.message,
				          type: 'success'
				        })
				  		//this.getTableData(1)
				  		setTimeout(function(){
							_this.$router.push('/yjw_cms_system/newsManage')
				        },700)
				  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
				  		console.log(nowData.message)
				  		this.$message({
				          message: nowData.message,
				          type: 'warning'
				        })
				  	}		  			
				  })
				  .catch((err) => {
				    console.log(err);
				    this.$message({
			          message: err,
			          type: 'warning'
			        })
				  })   	
	          
	        }).catch(() => {
	          this.$message({
	            type: 'info',
	            message: '已取消'
	          })        
	        })	
		},
     	saveDate(){
      		
  			let parm = {
		  		   "classify": this.form.menu,
				    "content": this.getUEContent(),
			   "introduction": this.form.introduction,
				 "policyTime": this.form.date? this.common.fomatDate(this.form.date,1) : '',
				      "title": this.form.title,
				     "issued": this.form.checked == true? 0 : 1,
				    	"img": this.imageUrl,
				    "creator": this.common.SStorage.getItem('saveUserInfo').id,
		  		     "signId": this.GLOBAL.userid
		  	}
  			console.log(JSON.stringify(parm))
				let baseParmUser = this.common.DataToBase64(JSON.stringify(parm))
				this.$axios.post('/yjw-CMS/article/add?data='+baseParmUser+'&sign='+this.GLOBAL.urlStr(parm))
					
				  .then((res) => {				  	
				  	let nowData = JSON.parse(this.common.base64ToData(res.data))
				  	console.log(nowData)
				  	if(nowData.code == 0){	
				  		this.articleId = nowData.result					  						  	
					  	this.$message({
				          message: nowData.message,
				          type: 'success'
				        })					  	
					  	
				  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
				  		console.log(nowData.message)
				  		this.$message({
				          message: nowData.message,
				          type: 'warning'
				        })
				  	}
				  	
				  })
				  .catch((err) => {
				    console.log(err);
				    this.$message({
			          message: err,
			          type: 'warning'
			        })
				  })       		
     	}
    },
    created (){
    	
    },
    mounted(){
    	
    }
  }		
</script>

<style scoped>
.page-title{
	border-bottom: 1px solid #999; text-align: left; padding: 20px 0; margin-top: 30px; position: relative;
}	
.page-body{
	margin-top: 30px; /*width: 800px;*/
}

.avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    text-align: center;
    width: 122px; height: 122px; 
    line-height: 122px; 
    border: 1px dashed #d0cece; 
    cursor: pointer;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>