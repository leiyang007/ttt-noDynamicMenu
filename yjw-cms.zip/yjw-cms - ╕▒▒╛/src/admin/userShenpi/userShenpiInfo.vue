<template>
	<div class="shenpi">
		<div class="content-nav">
			<ul>
				<li>
					<a href="javascript:history.go(-1)">返回上一步</a>
				</li>
				<li><i class="el-icon-arrow-right"></i></li>
				<li class="blue-font">企业审核</li>
			</ul>
		</div>
		<div class="page-title">
			<p>企业概况</p>
			<el-button type="warning" style="position: absolute; top: 10px; right: 10px;" @click="dialogFormVisible = true" v-show="status == 2">审核</el-button>
		</div>
		<div class="qygk-info">
			<ul>
				<li>
					<div>
						<label>企业名称:</label>
						<span>{{ pageData.compInfo.companyName }}</span>
					</div>
					<div>
						<label>纳税人识别号:</label>
						<span>{{ pageData.compInfo.taxpayerRegistrationNumber }}</span>
					</div>
				</li>
				<li>
					<div>
						<label>企业类型:</label>
						<span>{{ pageData.compInfo.companyType | fomatCompanyType}}</span>
					</div>
					<div>
						<label>注册资金:</label>
						<span>{{ pageData.compInfo.registeredCapital }}万<span>{{ pageData.compInfo.registeredType == 1 ? '美' : '' }}</span>元</span>
					</div>
				</li>
				<li>
					<div>
						<label>企业地址:</label>
						<span>{{ pageData.compInfo.location }}</span>
					</div>
					<div>
						<label>经营范围:</label>
						<span>{{ pageData.compInfo.businessScope }}</span>
					</div>
				</li>
				<li>
					<div>
						<label>企业法人:</label>
						<span>{{ pageData.compInfo.legalPerson }}</span>
					</div>
					<div>
						<label>经营范围详细:</label>
						<span>{{ pageData.compInfo.businessScopeDesc }}</span>
					</div>
				</li>
				<li>
					<div>
						<label>企业第一联系人:</label>
						<span>{{ pageData.compInfo.contactPerson1 }}</span>
					</div>
					<div>
						<label>联系方式:</label>
						<span>{{ pageData.compInfo.phone1 }}</span>
					</div>
				</li>
				<li>
					<div>
						<label>企业第二联系人:</label>
						<span>{{ pageData.compInfo.contactPerson2 }}</span>
					</div>
					<div>
						<label>联系方式:</label>
						<span>{{ pageData.compInfo.phone2 }}</span>
					</div>
				</li>
				<li>
					<div>
						<label>企业第三联系人:</label>
						<span>{{ pageData.compInfo.contactPerson3 }}</span>
					</div>
					<div>
						<label>联系方式:</label>
						<span>{{ pageData.compInfo.phone3 }}</span>
					</div>
				</li>
			</ul>
		</div>
		<div class="page-title" v-if="companyType != 3">
			<p>企业基本资料</p>
		</div>
		<div class="qygk-info qugk-img-info" v-if="companyType != 3">
			<ul>
				<li>
					<div>
						<label>营业执照附件:</label>
						<el-popover
						  placement="right"
						  trigger="click">
						  <div :style="imgStyle">
						  	<img :src="businessLicense" alt="" />
						  </div>						  
						  <el-button slot="reference"><img class="little-img" :src="businessLicense" alt="" /></el-button>
						</el-popover>
					</div>
					<div>
						<label>企业公章:</label>
						<el-popover
						  placement="right"
						  trigger="click">
						  <div :style="imgStyle">
						  	<img :src="companySeal" alt="" />
						  </div>						  
						  <el-button slot="reference"><img class="little-img" :src="companySeal" alt="" /></el-button>
						</el-popover>
					</div>
				</li>
			</ul>
		</div>
		<div class="page-title" v-if="companyType == 2">
			<p>生产厂家必备资料</p>
		</div>
		<div class="qygk-info qugk-img-info" v-if="companyType == 2">
			<ul>
				<li>
					<div>
						<label>医疗器械生产许可证:</label>
						<el-popover
						  placement="right"
						  trigger="click">
						  <div :style="imgStyle">
						  	<img :src="medicalEquipmentProductionLicense" alt="" />
						  </div>						  
						  <el-button slot="reference"><img class="little-img" :src="medicalEquipmentProductionLicense" alt="" /></el-button>
						</el-popover>
					</div>
				</li>
				<li>
					<div class="any-more-img">
						<label>医疗器械注册证:<span class="red-font">(可以多个)</span></label>
						<template v-for="item in pageData.compDocumentInfos">
							<el-popover
							  placement="right"
							  trigger="click">
							  <div :style="imgStyle">
							  	<img :src="item.medicalDeviceRegistration" alt="" />
							  </div>						  
							  <el-button slot="reference"><img class="little-img" :src="item.medicalDeviceRegistration" alt="" /></el-button>
							</el-popover>
						</template>						
					</div>
				</li>
			</ul>
		</div>
		<div class="page-title" v-if="companyType == 0">
			<p>医疗机构必备资料</p>
		</div>
		<div class="qygk-info qugk-img-info" v-if="companyType == 0">
			<ul>
				<li>
					<div>
						<label>医疗机构执业许可证:</label>
						<el-popover
						  placement="right"
						  trigger="click">
						  <div :style="imgStyle">
						  	<img :src="medicalOperationLicence" alt="" />
						  </div>						  
						  <el-button slot="reference"><img class="little-img" :src="medicalOperationLicence" alt="" /></el-button>
						</el-popover>
					</div>
				</li>
			</ul>
		</div>		
		<div class="page-title" v-if="companyType == 1">
			<p>经销商必填资料</p>
		</div>
		<div class="qygk-info qugk-img-info" v-if="companyType == 1">
			<ul>
				<li>
					<div>
						<label>医疗器械经营企业许可证:</label>
						<el-popover
						  placement="right"
						  trigger="click">
						  <div :style="imgStyle">
						  	<img :src="medicalEquipmentBusinessLicense" alt="" />
						  </div>						  
						  <el-button slot="reference"><img class="little-img" :src="medicalEquipmentBusinessLicense" alt="" /></el-button>
						</el-popover>
					</div>
					<div>
						<label>医疗器械经营备案许可证:</label>						
						<template v-for="item in pageData.compDocumentInfos">
							<el-popover
							  placement="right"
							  trigger="click">
							  <div :style="imgStyle">
							  	<img :src="item.medicalEquipmentManagementRecordLicense" alt="" />
							  </div>						  
							  <el-button slot="reference"><img class="little-img" :src="item.medicalEquipmentManagementRecordLicense" alt="" /></el-button>
							</el-popover>
						</template>	
					</div>
				</li>
			</ul>
		</div>	
		
		<el-dialog title="审核" :visible.sync="dialogFormVisible">
		  <el-form :model="form">
		    <el-form-item class="is-required" label="审核结果" :label-width="formLabelWidth">
		      <el-select v-model="form.shenheResult" placeholder="请选择">
		        <el-option label="审核通过" value="0"></el-option>
		        <el-option label="审核不通过" value="1"></el-option>
		      </el-select>
		    </el-form-item>
		    <el-form-item class="is-required" label="备注" :label-width="formLabelWidth">
		      <el-input
				  type="textarea"
				  :rows="2"
				  placeholder="请输入内容"
				  style="width: 300px;"
				  v-model="form.textarea">
				</el-input>
		    </el-form-item>
		  </el-form>
		  <div slot="footer" class="dialog-footer">
		    <el-button @click="cancel">取 消</el-button>
		    <el-button type="primary" @click="confirm">确 定</el-button>
		  </div>
		</el-dialog>
		<!--<div class="img-show-mask"></div>-->
	</div>
</template>

<script>

  export default {
	filters: {
	  fomatCompanyType: function (value) {
	    if(value == 0){
	    	return '医疗机构'
	    }else if(value == 1){
	    	return '经销商'
	    }else if(value == 2){
	    	return '生产厂家'
	    }else if(value == 3){
	    	return '监管机构'
	    }
	  }
	},
  	computed: {	
	    businessLicense(){	//营业执照
	      return this.pageData.compDocument.businessLicense
	    },
	    companySeal(){	//企业公章   
	      return this.pageData.compDocument.companySeal
	    },
	    medicalEquipmentProductionLicense(){	//医疗器械生产许可证  生产厂家
	      return this.pageData.compDocument.medicalEquipmentProductionLicense
	    },
	    medicalOperationLicence(){	//医疗机构执业许可证    医疗机构
	      return this.pageData.compDocument.medicalOperationLicence
	    },
	    medicalEquipmentBusinessLicense(){	//医疗器械经营企业许可证   经销商
	      return this.pageData.compDocument.medicalEquipmentBusinessLicense
	    },
	    medicalEquipmentManagementRecordLicense(){	//医疗器械经营备案许可证   经销商
	      return this.pageData.compDocumentInfos.medicalEquipmentManagementRecordLicense
	    }
	},
  	data (){
  		return {
  			//moneyType: this.pageData.compInfo.registeredType == 1 ? '美元' : '',
  			companyType: null,
  			taskId: this.$route.query.id,
  			pageData: {},
  			isShowLogDialog: false,
  			dialogFormVisible: false,
	        form: {
	          shenheResult: '',
	          textarea: ''
	        },
	        formLabelWidth: '90px',
	        status: null,     //判断状态
	        imgStyle: {
	        	width: '1000px',
	        	height: '800px',
	        	overflow: 'auto'
	        }
	  	}
  	},
    methods: { 
    	confirm(){
    		console.log(JSON.stringify(this.form))
    		let _this = this
    		  	let parm = {
			  		 	"taskId": this.taskId,
					    "remark": this.form.textarea,
					    "status": this.form.shenheResult,
					    "signId": this.GLOBAL.userid
			  		}
  				console.log(parm)
				let baseParmUser = this.common.DataToBase64(JSON.stringify(parm))
				this.$axios.post('/yjw-CMS/company/updateTask?data='+baseParmUser+'&sign='+this.GLOBAL.urlStr(parm))
					
				  .then((res) => {				  	
				  	let nowData = JSON.parse(this.common.base64ToData(res.data))
				  	console.log(nowData)
				  	if(nowData.code == 0){	
				  		console.log(JSON.stringify(nowData.result))
				  	
					  	this.$message({
				          message: nowData.message,
				          type: 'success'
				        })					  	
					  	this.dialogFormVisible = false
					  	setTimeout(function(){
					  		_this.$router.push('/yjw_cms_system/userShenpiList')
							window.location.reload()
					  	},700)
				  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
				  		console.log(nowData.message)
				  		this.$message({
				          message: nowData.message,
				          type: 'warning'
				        })
				  	}
				  	
				  })
				  .catch((err) => {
				    console.log(err);
				    this.$message({
			          message: err,
			          type: 'warning'
			        })
				  }) 
    	},
    	cancel(){
    		this.dialogFormVisible = false
    	},
     	showData(){
      		let _this = this
      		console.log(this.taskId)
      		this.companyType = this.$route.query.companyType     //传过来公司类型
  			let parm = {
		  		 "companyId": this.taskId,
		  		    "signId": this.GLOBAL.userid
		  	}
  			console.log(parm)
				let baseParmUser = this.common.DataToBase64(JSON.stringify(parm))
				this.$axios.post('/yjw-CMS/company/getCompanyCheck?data='+baseParmUser+'&sign='+this.GLOBAL.urlStr(parm))
					
				  .then((res) => {				  	
				  	let nowData = JSON.parse(this.common.base64ToData(res.data))
				  	console.log(nowData)
				  	if(nowData.code == 0){	debugger
				  		//console.log(JSON.stringify(nowData.result))
				  		_this.pageData = nowData.result 
				  		_this.status = this.pageData.compInfo.status
					  	console.log(JSON.stringify(_this.pageData))
					  						  	
					  	this.$message({
				          message: nowData.message,
				          type: 'success'
				        })					  	
					  	
				  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
				  		console.log(nowData.message)
				  		this.$message({
				          message: nowData.message,
				          type: 'warning'
				        })
				  	}
				  	
				  })
				  .catch((err) => {
				    console.log(err);
				    this.$message({
			          message: err,
			          type: 'warning'
			        })
				  })       		
     	}
    },
    created (){
    	
    },
    mounted(){
    	this.showData()
    	
    }
  }		
</script>

<style type="text/css">
.shenpi	.el-form-item__content{
	text-align: left;
}
.shenpi	.el-dialog{
	width: 500px;
}
.shenpi	.el-dialog__header{
	text-align: left;
}
.shenpi	.el-form-item.is-required .el-form-item__label:before{
	content: "*";
    color: #f56c6c;
    margin-right: 4px;
}
</style>

<style scoped>
.page-title:first-child{
	margin-top: 0px;
}
.page-title{
	border-bottom: 1px solid #999; text-align: left; padding: 20px 0; margin-top: 30px; position: relative;
}	
.qygk-info ul li{
	overflow: hidden; margin: 40px 0 0 40px;
}
.qygk-info ul li div{
	float: left;
}
.qygk-info ul li div:first-child{
	margin-right: 300px;
}	
.qygk-info ul li div > span{
	border-bottom: 1px solid #666; display: inline-block; margin-left: 20px; color: #008BDA; width: 220px;
}
.qygk-info ul li div > img{
	width: 200px; height: 112px;
}
.qygk-info ul li div .little-img{
	width: 200px; height: 112px;
}
.qygk-info:last-child{
	margin-bottom: 60px;
}
.qugk-img-info ul li div:first-child{
	margin-right: 150px; 
}
.qugk-img-info ul li div label{
	width: 120px; display: inline-block; margin-right: 10px;
}
.any-more-img img{
	margin: 0 10px 10px 0;
}

</style>