<template>
	<div>
		<div class="content-nav">
			<ul>
				<li>
					<!--<router-link :to="{path: '/yjw_cms_system/roleAuthorityMmanage'}">
						返回上一步
					</router-link>-->
					<a href="javascript:history.go(-1)">返回上一步</a>
				</li>
				<li><i class="el-icon-arrow-right"></i></li>
				<li class="blue-font">权限列表</li>
			</ul>
		</div>
		<div class="table-head clear">
			<ul class="clear">
				<li>	
					<div class="demo-input-suffix">
						角色编号: <span class="yellow-font">{{ jueseSn }}</span>
					</div>
				</li>
				<li>	
					<div class="demo-input-suffix">
						角色名称: <span class="yellow-font">{{ jueseName }}</span>
					</div>
				</li>
				<li>	
					<div class="demo-input-suffix">
						企业类型: <span class="yellow-font">{{ companyType }}</span>
					</div>
				</li>
				<li style="margin-left: 230px;">
					<el-button type="primary" @click="saveBut()">保存</el-button>
				</li>
			</ul> 
		</div>
		<div class="table-body">
			<ul id="ruleList" class="role-table col-xs-offset-2 col-md-offset-1 col-sm-offset-2" style="width: 800px; margin-top: 20px;">
			    <li class="header">
			        <div class="left">一级菜单</div>
			        <div class="right">二级菜单</div>
			    </li>
			    <div class="vertical-line"></div>
			    <li  v-for="(item,index) in tableData" >
			        <div class="left h40" >	
			            <el-checkbox @change="handleOneCheckAll($event,item)" :data-id="item.id" v-model="item.isCheck"></el-checkbox>
			            <span>{{item.menuName}}</span>
			        </div>
			        <div class="line"></div>
			        <ul>
			            <li class="h40" v-for="(second,cur) in item.children" >
			                <div class="right">			                	
			                    <el-checkbox v-model="second.isCheck" :data-id="second.id" @change="handleCheckAllChange($event,item,second)"></el-checkbox>
			                    <span>{{second.menuName}}</span>
			                </div>
			                <div class="line"></div>
			            </li>
			        </ul>
			    </li>
			</ul>
			<!--<template>
			  <el-table :data="tableData" border style="width: 100%">
			    <el-table-column prop="" label="一级菜单" width="300">
			    	<template slot-scope="scope">
			    		<el-checkbox v-model="scope.row.isCheck">{{ scope.row.menuName }}</el-checkbox>
			    	</template>	
			    </el-table-column>
			    <el-table-column prop="" label="二级菜单" width="300">
			    	<template slot-scope="scope">
			    		<el-checkbox v-model="scope.row.isCheck">{{ scope.row.menuName }}</el-checkbox>
			    	</template>	
			    </el-table-column>			    
			  </el-table>
			</template>	-->		
		</div>
	</div>
</template>

<script>
  export default {
  	data (){
  		return {
  			jueseSn: this.$route.query.sn,
  			jueseName: this.$route.query.name,
  			companyType: null,
  			companyTypeList: [
  				{
  					id: 0,
  					name: '医院',
  				},
  				{
  					id: 1,
  					name: '经销商',
  				},
  				{
  					id: 2,
  					name: '生产商',
  				},
  				{
  					id: 3,
  					name: '监管机构',
  				}
  			],
  			checkList: [],		//选中行数据ID,用于保存传参
  			tableData: [],
  			checkTableData: []		//临时用来存放table数据的新数组
  		}
  	},
    methods: {
    	saveBut(){
    		let _this = this
    		let checkSelectId = $('.table-body label.is-checked')

    		_this.checkList = []
    		for(let i=0; i<checkSelectId.length; i++){
    			//console.log(checkSelectId[i].dataset.id)
    			_this.checkList.push(checkSelectId[i].dataset.id)
    		}
    		
    		console.log('所有页面勾选的数据---->>>>'+JSON.stringify(_this.checkList))

    		let arr = this.filterArr(this.checkList)
			this.checkList = arr.map(function(currentValue,index){
					return {
					        "menuId": currentValue			
						}
				})
    	
    		console.log('过滤后的数据ID:'+JSON.stringify(arr))
    		console.log('要传的参数:'+JSON.stringify(this.checkList))
    		//console.log('表格数据:'+JSON.stringify(_this.tableData))
    		this.updateRole(this.checkList)		//调用更新方法
    	},
    	updateRole(arrId){
    		let parm = {
						    "role":{
						        "sn": this.$route.query.sn,
						      "name": this.$route.query.name
						    },
						      "list": arrId,
						    "signId": this.GLOBAL.userid
						}
  			console.log(JSON.stringify(parm))
				let baseParmUser = this.common.DataToBase64(JSON.stringify(parm))
				this.$axios.post('/yjw-CMS/yuser/updateRole?data='+baseParmUser+'&sign='+this.GLOBAL.urlStr(parm))
					
				  .then((res) => {				  	
				  	let nowData = JSON.parse(this.common.base64ToData(res.data))
				  	console.log(nowData)
				  	if(nowData.code == 0){	
				  		console.log(JSON.stringify(nowData.result))

					  	this.$message({
				          message: nowData.message,
				          type: 'success'
				        })					  	
					  	
				  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
				  		console.log(nowData.message)
				  		this.$message({
				          message: nowData.message,
				          type: 'warning'
				        })
				  	}
				  	
				  })
				  .catch((err) => {
				    console.log(err);
				    this.$message({
			          message: err,
			          type: 'warning'
			        })
				  }) 
    	},
    	filterArr(arr){				//过滤数组中重复值
    		var result = [], hash = {};
		    for (var i = 0, elem; (elem = arr[i]) != null; i++) {
		        if (!hash[elem]) {
		            result.push(elem);
		            hash[elem] = true;
		        }
		    }
		    return result;
    	},
    	handleOneCheckAll(event,item){
    		console.log(JSON.stringify(event))
    		console.log(JSON.stringify(item))
    		console.log(JSON.stringify(this.tableData))
    		
    		if(item.children){
    			if(event == false){
	    			item.children.forEach(function(e,index){
	    				e.isCheck = false
	    			})
	    		}else{
	    			item.children.forEach(function(e,index){
	    				e.isCheck = true
	    			})
	    		}
    		}
    		
    	},
    	handleCheckAllChange(event,item,second){
    		console.log(JSON.stringify(event))
    		console.log(JSON.stringify(item))
    		console.log(JSON.stringify(second))
    		console.log(JSON.stringify(this.tableData))
			
			let isCheckFirst = this.isInArray(item.children,true)
			if(isCheckFirst){
				item.isCheck = true
			}else{
				item.isCheck = false
			}		
			console.log(isCheckFirst)
    	},
    	isInArray(arr,value){				//判断元素是否在数组中
		    for(var i = 0; i < arr.length; i++){
		        if(value === arr[i].isCheck){
		            return true;
		        }
		    }
		    return false;
		},
    	getCompanyType(val){
			console.log(val)
		},
     	queryData(parmPage){
  			let parm = {
				    "roleSn": this.$route.query.sn,
				    "signId": this.GLOBAL.userid
		  	}
  			console.log(parm)
				let baseParmUser = this.common.DataToBase64(JSON.stringify(parm))
				this.$axios.post('/yjw-CMS/yuser/selectMenu?data='+baseParmUser+'&sign='+this.GLOBAL.urlStr(parm))
					
				  .then((res) => {				  	
				  	let nowData = JSON.parse(this.common.base64ToData(res.data))
				  	console.log(nowData)
				  	if(nowData.code == 0){	
				  		//console.log(JSON.stringify(nowData.result))

						// 属性配置信息
						let attributes = {
						      id: 'id',
						      parentId: 'parentMenuId',
						      name: 'menuName',
						      dpSn: 'isCheck',
						      rootId: '0'
						  };
						let treeData = this.common.toTreeData(nowData.result, attributes)
						
						this.tableData = treeData
						console.log(JSON.stringify(this.tableData))
						
					  	this.$message({
				          message: nowData.message,
				          type: 'success'
				        })					  	
					  	
				  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
				  		console.log(nowData.message)
				  		this.$message({
				          message: nowData.message,
				          type: 'warning'
				        })
				  	}
				  	
				  })
				  .catch((err) => {
				    console.log(err);
				    this.$message({
			          message: err,
			          type: 'warning'
			        })
				  })       		
     	},
     	formatCompanyType(){
    		if(this.$route.query.roleType == 0){
    			this.companyType = '医院类型的消费者'
    		}else if(this.$route.query.roleType == 1){
    			this.companyType = '经销商'
    		}else if(this.$route.query.roleType == 2){
    			this.companyType = '生产厂家'
    		}else{
    			this.companyType = '监管机构'
    		}
    	}
    },
    created (){
    	
    },
    mounted(){
    	this.queryData()
    	this.formatCompanyType()   //展示企业类型

    }
  }		
</script>

<style scope>
.table-head{
	padding: 10px 0; border-bottom: 1px solid #DCDFE6;	
}
.table-head ul li{
	float: left; margin: 0 20px 10px 0;
}		

.role-table {
    border: 1px solid #e0e0e0;
    border-bottom: none;
    padding: 0;
    position: relative;
}

.header {
    height: 40px;
    line-height: 40px;
    border-bottom: 1px solid #e7e7e7;
    background: #F8F8F9;
    text-align: center;
}

.vertical-line {
    width: 1px;
    height: 100%;
    background: #ddd;
    position: absolute;
    left: 30%;
    top: 0
}

.left {
    width: 30%;
    float: left;
    padding-left: 10px;
    user-select: none;
    cursor: pointer;
}

.one {
    padding-left: 20px;
}

.right {
    width: 60%;
    float: right;
    padding-left: 10px;
}

.item-icon {
    margin-left: -5px;
    padding: 5px;
}

.line {
    clear: both;
    width: 100%;
    height: 1px;
    background: #e0e0e0;
}
.h40{
    height: 39px;
    line-height: 39px;
}
</style>