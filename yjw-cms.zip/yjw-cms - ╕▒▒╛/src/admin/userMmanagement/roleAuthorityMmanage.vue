<template>
	<div>
		<div class="table-head clear">
			<ul class="clear">
				<li>	
					<div class="demo-input-suffix">
					  <el-input v-model="jueseSnName" placeholder="角色编号/角色名称" style="width: 200px;"></el-input>
					</div>
				</li>
				<li>
					<el-button type="primary" @click="checkBut(1)">查询</el-button>
				</li>
				<!--<li style="margin-left: 30px;">
					<router-link :to="{path: '/yjw_cms_system/roleAuthorityMmanageAdd'}">
						<el-button type="warning" @click="addPage">新增</el-button>
					</router-link>
				</li>-->
			</ul> 
		</div>
				<div class="table-body">
			<template>
			  <el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%;text-align: left;">			    
			    <el-table-column prop="sn" label="角色编号">
			    </el-table-column>
			    <el-table-column prop="name" label="角色名称">
			    </el-table-column>
			    <el-table-column prop="roleType" label="所属企业类型" :formatter="formatUserType">
			    </el-table-column>	
			    <el-table-column prop="currentHumidity" label="操作">
			    	<template slot-scope="scope">
			    		<router-link :to="{path: '/yjw_cms_system/roleAuthorityMmanageUpdate',query:{
			    			   		  sn: scope.row.sn,
			    			   		name: scope.row.name,
			    			   	roleType: scope.row.roleType
			    			}}">
			    			<i class="el-icon-edit" style="margin-left: 10px;" title="修改"></i>		
			    		</router-link>
			    	</template>
			    </el-table-column>			    
			  </el-table>
			    <el-pagination
			      @size-change="handleSizeChange"
			      @current-change="handleCurrentChange"
			      :current-page.sync="nowPage"
			      :page-size="pageSize"
			      layout="prev, pager, next, jumper"
			      :total="totalCount">
			    </el-pagination>
			</template>				
		</div>
	</div>
</template>

<script>
  export default {
  	data (){
  		return {
  			nowPage: 1,								//当前页
	      	pageSize: this.GLOBAL.pageSize,			//每页显示条数
	      	totalCount: 0,							//总条数
  			jueseSnName: null,
  			tableData: []
  		}
  	},
    methods: {
     	checkBut(parmPage){
     		this.queryData(parmPage)
     	},
     	addPage(){
     		
     	},
    	formatUserType(row, column){
    		if(row.roleType == 0){
    			return '医院类型的消费者'
    		}else if(row.roleType == 1){
    			return '经销商'
    		}else if(row.roleType == 2){
    			return '生产厂家'
    		}else{
    			return '监管机构'
    		}
    	},
     	queryData(parmPage){
      		let _this = this
  			let parmUser = {
				    "name": this.jueseSnName,
				    "pageNum": parmPage ? parmPage : this.nowPage,
				    "pageSize": this.pageSize,
				    "signId": this.GLOBAL.userid
		  	}
  			console.log(parmUser)
				let baseParmUser = this.common.DataToBase64(JSON.stringify(parmUser))
				this.$axios.post('/yjw-CMS/yuser/selectRole?data='+baseParmUser+'&sign='+this.GLOBAL.urlStr(parmUser))
					
				  .then((res) => {				  	
				  	let nowData = JSON.parse(this.common.base64ToData(res.data))
				  	console.log(nowData)
				  	if(nowData.code == 0){	
				  		console.log(JSON.stringify(nowData.result))
				  		this.tableData = nowData.result.list
				  		this.totalCount = nowData.result.total
					  	this.$message({
				          message: nowData.message,
				          type: 'success'
				        })					  	
					  	
				  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
				  		console.log(nowData.message)
				  		this.$message({
				          message: nowData.message,
				          type: 'warning'
				        })
				  	}
				  	
				  })
				  .catch((err) => {
				    console.log(err);
				    this.$message({
			          message: err,
			          type: 'warning'
			        })
				  })       		
     	},
    	handleSizeChange(val){
    		this.pageSize = val
    		console.log(this.pageSize)
    	},
    	handleCurrentChange(val){
    		this.nowPage = val
    		console.log('当前页是:'+this.nowPage)
    		this.queryData()
    	},	
    },
    created (){
    	
    },
    mounted(){
    	this.queryData()
    }
  }		
</script>

<style scope>
.table-head{
	padding: 10px 0; border-bottom: 1px solid #DCDFE6;	
}
.table-head ul li{
	float: left; margin: 0 20px 10px 0;
}		
</style>