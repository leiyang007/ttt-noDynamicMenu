<template>
	<div>
		<div class="table-head clear">
			<ul class="clear">
				<li>	
					<div class="demo-input-suffix">
					  <span>用户姓名:</span>
					  <el-input v-model="userName" placeholder="请输入姓名" style="width: 200px;"></el-input>
					</div>
				</li>
				<li>	
					<div class="demo-input-suffix">
					  <span>所属单位:</span>
					  <el-input v-model="ownCompany" placeholder="请输入单位名称" style="width: 200px;"></el-input>
					</div>
				</li>
				<li>	
					<div class="demo-input-suffix">
					  <span>联系方式:</span>
					  <el-input v-model="phoneNum" placeholder="请输入联系方式" style="width: 200px;"></el-input>
					</div>
				</li>
				<li>
					<el-button type="primary" @click="checkBut">查询</el-button>
				</li>
				<li>
					<el-button type="info" @click="reset">重置</el-button>
				</li>
				<!--<li style="margin-left: 30px;" v-show="roleName == '库管员'">
					<router-link :to="{path: '/yjw_admin/outOfStorageInfo'}">
						<el-button type="warning" @click="reset">新增</el-button>
					</router-link>
				</li>-->
			</ul> 
		</div>
				<div class="table-body">
			<template>
			  <el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%;text-align: left;">			    
			    <el-table-column prop="userName" label="用户账号">
			    </el-table-column>
			    <el-table-column prop="userSn" label="用户编号">
			    </el-table-column>
			    <el-table-column prop="name" label="姓名">
			    </el-table-column>	
			    <el-table-column prop="sex" label="性别" :formatter="formatSex">
			    </el-table-column>	
			    <el-table-column prop="companyName" label="所属单位">
			    </el-table-column>
			    <el-table-column prop="userType" label="单位性质" :formatter="formatUserType">
			    </el-table-column>
			    <el-table-column prop="departmentName" label="所属部门">
			    </el-table-column>
			    <el-table-column prop="roleName" label="个人角色">
			    </el-table-column>
			    <el-table-column prop="phone" label="联系方式">
			    </el-table-column>
			    <el-table-column prop="state" label="用户状态" :formatter="formatState">
			    </el-table-column>
			    <el-table-column prop="currentHumidity" label="操作">
			    	<template slot-scope="scope">
			    		<el-popover
						  placement="right"
						  width="400"
						  trigger="click">
						  	<el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2" label-width="100px" class="demo-ruleForm">
							  <el-form-item label="密码" prop="pass">
							    <el-input type="password" v-model="ruleForm2.pass" auto-complete="off"></el-input>
							  </el-form-item>
							  <el-form-item label="确认密码" prop="checkPass">
							    <el-input type="password" v-model="ruleForm2.checkPass" auto-complete="off"></el-input>
							  </el-form-item>
							  <el-form-item>
							    <el-button type="primary" @click="submitForm('ruleForm2',scope.row.userName)">提交</el-button>
							    <el-button @click="resetForm('ruleForm2')">重置</el-button>
							  </el-form-item>
							</el-form>
						  <el-button slot="reference">重置密码</el-button>
						</el-popover>			    					    		
			    	</template>
			    </el-table-column>			    
			  </el-table>
			    <el-pagination
			      @size-change="handleSizeChange"
			      @current-change="handleCurrentChange"
			      :current-page.sync="nowPage"
			      :page-size="pageSize"
			      layout="prev, pager, next, jumper"
			      :total="totalCount">
			    </el-pagination>
			</template>				
		</div>
	</div>
</template>

<script>
  export default {
  	data (){
  		var validatePass = (rule, value, callback) => {
	        if (value === '') {
	          callback(new Error('请输入密码'));
	        } else {
	          if (this.ruleForm2.checkPass !== '') {
	            this.$refs.ruleForm2.validateField('checkPass');
	          }
	          callback();
	        }
	      };
	    var validatePass2 = (rule, value, callback) => {
	        if (value === '') {
	          callback(new Error('请再次输入密码'));
	        } else if (value !== this.ruleForm2.pass) {
	          callback(new Error('两次输入密码不一致!'));
	        } else {
	          callback();
	        }
	    };
  		return {
  			nowPage: 1,								//当前页
	      	pageSize: this.GLOBAL.pageSize,			//每页显示条数
	      	totalCount: 0,							//总条数
  			userName: null,
  			ownCompany: null,
  			phoneNum: null,
  			tableData: [],
	        ruleForm2: {
	          pass: '',
	          checkPass: ''
	        },
	        rules2: {
	          pass: [
	            { validator: validatePass, trigger: 'blur' }
	          ],
	          checkPass: [
	            { validator: validatePass2, trigger: 'blur' }
	          ]
	        }
  		}
  	},
    methods: {
    	submitForm(formName,username) {  //重置密码
    		let _this = this
	        if(this.ruleForm2.checkPass == this.ruleForm2.pass){
            	let parm = {
	  				    "username": username,
					    "password": this.ruleForm2.pass,
					    "signId": this.GLOBAL.userid
			  		}
	  			console.log(parm)
					let baseParmUser = this.common.DataToBase64(JSON.stringify(parm))
					this.$axios.post('/yjw-CMS/yuser/resetPassword?data='+baseParmUser+'&sign='+this.GLOBAL.urlStr(parm))
						
					  .then((res) => {				  	
					  	let nowData = JSON.parse(this.common.base64ToData(res.data))
					  	console.log(nowData)
					  	if(nowData.code == 0){	
					  		console.log(JSON.stringify(nowData.result))
						  	_this.$message({
					          message: nowData.message,
					          type: 'success'
					        })					  	
						  	//_this.queryData()

						  	setTimeout(function(){
						  		window.location.reload()
						  	},1000)					  	
					  	}else if(nowData.code == 800 || nowData.code == 500){
					  		console.log(nowData.message)
					  		this.$message({
					          message: '登录过期或重复登录!',
					          type: 'warning'
					        })
					  		setTimeout(function(){
					  				_this.common.SStorage.removeItem("saveUserInfo")
							  		_this.$router.push('/')
									window.location.reload()
							  	},1000)
					  	}else{
					  		console.log(nowData.message)
					  		this.$message({
					          message: nowData.message,
					          type: 'warning'
					        })
					  	}
					  	
					  })
					  .catch((err) => {
					    console.log(err);
					    this.$message({
				          message: err,
				          type: 'warning'
				        })
					  })  
	        }else{
		  		this.$message({
		          message: '两次密码不一致!',
		          type: 'warning'
		        })
	        }

	    },
	    resetForm(formName) {
	        //this.$refs[formName].resetFields();
	        /*this.$nextTick(()=>{debugger
                this.$refs[formName].resetFields();
            }) */
           this.ruleForm2.pass = ''
           this.ruleForm2.checkPass = ''
	    },
    	formatSex(row, column){
    		if(row.sex == 0){
    			return '女'
    		}else{
    			return '男'
    		}
    	},
    	formatUserType(row, column){
    		if(row.userType == 0){
    			return '医院类型的消费者'
    		}else if(row.userType == 1){
    			return '经销商'
    		}else if(row.userType == 2){
    			return '生产厂家'
    		}else{
    			return '监管机构'
    		}
    	},
    	formatState(row, column){
    		if(row.state == 0){
    			return '可用'
    		}else{
    			return '封号'
    		}
    	},
     	checkBut(){
     		this.queryData()
     	},
     	reset(){
     		this.userName = null
     		this.ownCompany = null
     		this.phoneNum = null
     	},
     	queryData(){
      		let _this = this
  			let parm = {
  				    "username": this.userName,
				    "companyName": this.ownCompany,
				    "phone": this.phoneNum,
				    "pageNum": this.nowPage,
				    "pageSize": this.pageSize,
				    "signId": this.GLOBAL.userid
		  	}
  			console.log(parm)
				let baseParmUser = this.common.DataToBase64(JSON.stringify(parm))
				this.$axios.post('/yjw-CMS/yuser/getUsers?data='+baseParmUser+'&sign='+this.GLOBAL.urlStr(parm))
					
				  .then((res) => {				  	
				  	let nowData = JSON.parse(this.common.base64ToData(res.data))
				  	console.log(nowData)
				  	if(nowData.code == 0){	
				  		console.log(JSON.stringify(nowData.result))
				  		this.tableData = nowData.result.list
				  		this.totalCount = nowData.result.total
					  	this.$message({
				          message: nowData.message,
				          type: 'success'
				        })					  	
					  	
				  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
				  		console.log(nowData.message)
				  		this.$message({
				          message: nowData.message,
				          type: 'warning'
				        })
				  	}
				  	
				  })
				  .catch((err) => {
				    console.log(err);
				    this.$message({
			          message: err,
			          type: 'warning'
			        })
				  })       		
     	},
    	handleSizeChange(val){
    		this.pageSize = val
    		console.log(this.pageSize)
    	},
    	handleCurrentChange(val){
    		this.nowPage = val
    		console.log('当前页是:'+this.nowPage)
    		this.queryData()
    	},	
    },
    created (){
    	
    },
    mounted(){
    	this.queryData()
    }
  }		
</script>

<style scope>
.table-head{
	padding: 10px 0; border-bottom: 1px solid #DCDFE6;	
}
.table-head ul li{
	float: left; margin: 0 20px 10px 0;
}		
</style>