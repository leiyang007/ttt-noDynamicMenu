<template>
  <div class="shenhe-dialog">
  		<div class="shenhe-head">
  			<span>审核</span>
  		</div>
  		<div class="shenhe-body">
  			<el-form :label-position="labelPosition" label-width="80px" :model="formLabelAlign">
				  <el-form-item label="审核结果">
				      <el-select v-model="value" placeholder="请选择">
						    <el-option
						      v-for="item in options"
						      :key="item.value"
						      :label="item.label"
						      :value="item.value">
						    </el-option>
						  </el-select>
				  </el-form-item>
				  <el-form-item label="备注">
				      <el-input
							  type="textarea"
							  :rows="2"
							  placeholder="最多输入50个字"
							  v-model="textarea">
							</el-input>
				  </el-form-item>
				</el-form>
  		</div>
  		
  </div>
</template>

<script scoped>
//import VueInputCode from 'vue-input-code' 
export default {
	components:{
		//VueInputCode		
	},
  data () {
    return {
        labelPosition: 'right',
        formLabelAlign: {},
         options: [{
          value: '选项1',
          label: '黄金糕'
        }, {
          value: '选项2',
          label: '双皮奶'
        }, {
          value: '选项3',
          label: '蚵仔煎'
        }, {
          value: '选项4',
          label: '龙须面'
        }, {
          value: '选项5',
          label: '北京烤鸭'
        }],
        value: ''
    }
  },
  mounted (){
    
  },
  methods: {  
  	
  },
  created (){
  		
  	
	  
  }

}
</script>

<style type="text/css">
.shenhe-dialog .el-form-item__content{
	text-align: left;
}	
</style>
<style scoped>
.shenhe-head{
	text-align: left; line-height: 30px; border-bottom: 1px solid #D7D7D7;
}	
.shenhe-body{
	margin-top: 30px;
}
</style>
