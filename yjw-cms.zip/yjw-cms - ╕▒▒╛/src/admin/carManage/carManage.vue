<template>
	<div class="car-manage">
		<div class="table-head clear">
			<ul class="clear">
				<li>	
					<div class="demo-input-suffix">
					  <el-input v-model="searchText" placeholder="搜索车牌号/注册公司" style="width: 300px;"></el-input>
					</div>
				</li>
				<li>
					<el-button type="primary" @click="checkBut(1)">查询</el-button>			
				</li>
			</ul> 
		</div>
		<div class="table-body">
			<template>
			  <el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%;text-align: left;">			    
			    <el-table-column prop="card" label="车牌号">
			    </el-table-column>
			    <el-table-column prop="carTypeString" label="车牌类型">
			    </el-table-column>
			    <el-table-column prop="belongPlatformString" label="车辆类型">
			    </el-table-column>
			    <el-table-column prop="departStatusString" label="发车状态">
			    </el-table-column>
			    <el-table-column prop="carImg" label="车辆照片">
			    	<template slot-scope="scope">				    		
		    			<el-popover
						  placement="right"
						  width="800"
						  trigger="click">
						  	<img :src="scope.row.carImg" style="width: 800px; height: 300px;" alt="" />
						  <el-button slot="reference">查看照片</el-button>
						</el-popover>					    			
			    	</template>
			    </el-table-column>
			    <el-table-column prop="companyName" label="注册公司">
			    </el-table-column>
			    <el-table-column prop="usableString" label="车辆是否可用">
			    </el-table-column>	
			    <el-table-column prop="" label="操作">
			    	<template slot-scope="scope">
			    		<i class="el-icon-circle-plus-outline" @click="addOne(scope.row,1)"></i>
			    		<i class="el-icon-view" style="margin-left: 10px;" @click="addOne(scope.row,2)" title="查看视频"></i>
			    	</template>
			    </el-table-column>
			  </el-table>
			    <el-pagination
			      @size-change="handleSizeChange"
			      @current-change="handleCurrentChange"
			      :current-page.sync="nowPage"
			      :page-size="pageSize"
			      layout="prev, pager, next, jumper"
			      :total="totalCount">
			    </el-pagination>
			</template>				
		</div>	
				
<!--添加弹窗-->
		<el-dialog :title="tanchuangBox" :visible.sync="dialogFormVisible">
		  <el-table ref="multipleTable" :data="tableData2" tooltip-effect="dark" style="width: 100%;text-align: left;">			    
			    <el-table-column prop="videoCode" label="视频编码">
			    	<template slot-scope="scope">
			    		<el-input v-model="scope.row.videoCode" placeholder="输入视频编码" v-if="!chakanVideo" style="width: 150px;"></el-input>
			    		<span v-text="scope.row.videoCode" v-if="chakanVideo"></span>
			    	</template>	
			    </el-table-column>
			    <el-table-column prop="videoSn" label="设备编码">
			    	<template slot-scope="scope">
			    		<el-input v-model="scope.row.videoSn" placeholder="输入设备编码" v-if="!chakanVideo" style="width: 150px;"></el-input>
			    		<span v-text="scope.row.videoSn" v-if="chakanVideo"></span>
			    	</template>		
			    </el-table-column>
			    <el-table-column prop="" label="操作">
			    	<template slot-scope="scope">
			    		<i class="el-icon-circle-plus-outline" v-if="!chakanVideo" @click="addOneLine(scope.row.carId)"></i>
			    		<i class="el-icon-remove-outline" v-if="!chakanVideo" @click="reduceOneLine(scope.row.carId)"></i>
			    		<i class="el-icon-view" style="margin-left: 10px;" v-if="chakanVideo" @click="viewVideo(scope.row)" title="查看视频"></i>
			    	</template>
			    </el-table-column>			    	    
			  </el-table>
		  <div slot="footer" class="dialog-footer">
		    <el-button @click="cancel">取 消</el-button>
		    <el-button type="primary" v-if="!chakanVideo" @click="confirm">确 定</el-button>
		  </div>
		</el-dialog>		
	</div>
</template>

<script>
export default{
	data(){
		return{
			userType: null,			//用户类型,如:厂家\经销商等
			nowPage: 1,				//当前页
	      	pageSize: this.GLOBAL.pageSize,			//每页显示条数
	      	totalCount: 0,			//总条数
			searchText: '',		   
			tableData: [],
			tableData2: [],
			dialogFormVisible: false,
			chakanVideo: false,
			tanchuangBox: ''
		}
	},	
	methods:{	
		viewVideo(row){
    		let parm = {		
    				  "videoSn": row.videoSn,
			     	   "signId": this.GLOBAL.userid
	    	}  

				let baseParm = this.common.DataToBase64(JSON.stringify(parm))
				console.log(JSON.stringify(parm))
					
			this.$axios.get('/yjw-CMS/wms/getVideoToken?data='+baseParm+'&sign='+this.GLOBAL.urlStr(parm))
			  .then((res) => {
			  	
			  	let nowData = JSON.parse(this.common.base64ToData(res.data))
				console.log(JSON.stringify(nowData))
			  	if(nowData.code == 0){	
			  		
			  		setTimeout(function(){
				       		window.open("../../../static/videoPlay.html?videoUrl="+nowData.result.hdAddress,'_blank','width=1000,height=800,top=50px,left=300px,location=no');				       	  		
			  		},500)
				       
			  		console.log(JSON.stringify(nowData.result))
			  		this.$message({
			          message: nowData.message,
			          type: 'success'
			        })
			  	}else{
			  		console.log(nowData.message)

			  		this.$message({
			          message: nowData.message,
			          type: 'warning'
			        })
			  	}		  			
			  })
			  .catch((err) => {
			    console.log(err);
			    this.$message({
		          message: err,
		          type: 'warning'
		        })
			  })
		},	
		addOneLine(sid){
			this.tableData2.push({
				  			"carId": sid,
				  			"videoCode": '',
				  			"videoSn": ''
			  			})
		},
		reduceOneLine(){
			if(this.tableData2.length > 1){
				this.tableData2.splice(-1,1)
			}else{
				this.$message({
			          message: '已经是最后一项了!',
			          type: 'warning'
			        })
			}			
		},		
		cancel(){
    		this.dialogFormVisible = false
    	},
		confirm(){
    		console.log(JSON.stringify(this.tableData2))
    		let strSn = ''
    		this.tableData2.forEach((item, index)=>{
    			strSn += item.videoCode + ':' + item.videoSn + ','
    		})
    		let parm = {
						     "carId": this.tableData2[0].carId,
						   "videoSn": strSn.substring(0,strSn.length-1),
			     			"signId": this.GLOBAL.userid
	    			}  

				let baseParm = this.common.DataToBase64(JSON.stringify(parm))
				console.log(JSON.stringify(parm))
					
			this.$axios.post('/yjw-CMS/wms/updateCar?data='+baseParm+'&sign='+this.GLOBAL.urlStr(parm))
			  .then((res) => {
			  	
			  	let nowData = JSON.parse(this.common.base64ToData(res.data))
				console.log(JSON.stringify(nowData))
			  	if(nowData.code == 0){		
			  		this.$message({
			          message: nowData.message,
			          type: 'success'
			        })
			  		this.cancel()
			  	}else{
			  		console.log(nowData.message)
			  		this.$message({
			          message: nowData.message,
			          type: 'warning'
			        })
			  	}		  			
			  })
			  .catch((err) => {
			    console.log(err);
			    this.$message({
		          message: err,
		          type: 'warning'
		        })
			  })
    	},
    	addOne(row,type){
			this.dialogFormVisible = true
			this.queryShebeiSn(row.carId,type)
			if(type == 2){
				this.chakanVideo = true
				this.tanchuangBox = '查看'
			}else{
				this.chakanVideo = false
				this.tanchuangBox = '添加'
			}
		},
		queryShebeiSn(sid,type){
    		let parm = {
						     "carId": sid,
			     			"signId": this.GLOBAL.userid
	    			}  

				let baseParm = this.common.DataToBase64(JSON.stringify(parm))
				console.log(parm)
					
			this.$axios.post('/yjw-CMS/wms/selectCarVideoSn?data='+baseParm+'&sign='+this.GLOBAL.urlStr(parm))
			  .then((res) => {
			  	
			  	let nowData = JSON.parse(this.common.base64ToData(res.data))
				console.log(JSON.stringify(nowData.result))
			  	if(nowData.code == 0){		
			  		this.tableData2 = nowData.result
			  		console.log(JSON.stringify(this.tableData2))
			  		this.$message({
			          message: nowData.message,
			          type: 'success'
			        })
			  	}else{
			  		console.log(nowData.message)
			  		if(type == 2){
			  			this.tableData2 = []
			  		}else{
			  			this.tableData2 = [
				  						{
					  			"carId": sid,
					  			"videoCode": '',
					  			"videoSn": ''
				  			}
				  		]
			  		}
			  		
			  	}		  			
			  })
			  .catch((err) => {
			    console.log(err);
			    this.tableData2 = [
			  						{
				  			"carId": sid,
				  			"videoCode": '',
				  			"videoSn": ''
			  			}
			  		]
			  })
		},		
		checkBut(type){
			this.getTableData(type)
		},		
		getTableData(type){
			let _this = this
    		let parm = {
					 	 "selectStr": this.searchText,
						   "pageNum": type? type : this.nowPage,
						  "pageSize": this.pageSize,
			     			"signId": this.GLOBAL.userid
	    			}  

				let baseParm = _this.common.DataToBase64(JSON.stringify(parm))
				console.log(parm)
					
			_this.$axios.post('/yjw-CMS/wms/selectForCarManage?data='+baseParm+'&sign='+_this.GLOBAL.urlStr(parm))
			  .then((res) => {
			  	
			  	let nowData = JSON.parse(_this.common.base64ToData(res.data))
				console.log(JSON.stringify(nowData.result))
			  	if(nowData.code == 0){		
			  		this.tableData = nowData.result.list
			  		this.totalCount = nowData.result.total
			  		console.log(JSON.stringify(this.tableData))
			  		this.$message({
			          message: nowData.message,
			          type: 'success'
			        })
			  	}else if(nowData.code == 800 || nowData.code == 500){
				  		console.log(nowData.message)
				  		this.$message({
				          message: '登录过期或重复登录!',
				          type: 'warning'
				        })
				  		setTimeout(function(){
				  				_this.common.SStorage.removeItem("saveUserInfo")
						  		_this.$router.push('/')
								window.location.reload()
						  	},1000)
				  	}else{
			  		console.log(nowData.message)
			  		this.$message({
			          message: nowData.message,
			          type: 'warning'
			        })
			  	}		  			
			  })
			  .catch((err) => {
			    console.log(err);
			    this.$message({
		          message: err,
		          type: 'warning'
		        })
			  })
		},
 		handleSizeChange(val){
    		this.pageSize = val
    		console.log(this.pageSize)
    	},
    	handleCurrentChange(val){
    		this.nowPage = val
    		console.log('当前页是:'+this.nowPage)
    		this.getTableData()
    	}	 
		
	},
	mounted (){
		this.getTableData()	
		
		this.userType = this.common.SStorage.getItem("saveUserInfo").userType 
	}	
}
</script>
<style type="text/css">

/*弹窗*/
.car-manage .el-form-item__content{
	text-align: left;
}
.car-manage .el-dialog{
	width: 600px;
}
.car-manage .el-dialog__header{
	text-align: left;
}
.car-manage .el-dialog__body{
	max-height: 368px;
    overflow-y: auto;
}
</style>
<style scoped>
.table-head{
	padding: 10px 0; border-bottom: 1px solid #DCDFE6;	
}
.table-head ul li{
	float: left; margin: 0 20px 10px 0;
}	

</style>