//引入项目依赖模块
import Vue from 'vue'
import VueRouter from 'vue-router'
import 'babel-polyfill'

//import VueResource from 'vue-resource'
import axios from 'axios'
import base64 from 'js-base64'
import store from '../store/index'

import ElementUI from 'element-ui'	
import 'element-ui/lib/theme-chalk/index.css'

//import md5 from 'js-md5'
import common from './assets/js/common.js'    //引入公共js文件

import SIdentify from './components/base/veriCode'		//验证码模块

/*引入UE模块*/
import '../static/UE/ueditor.config.js'
import '../static/UE/ueditor.all.js'
import '../static/UE/lang/zh-cn/zh-cn.js'
import '../static/UE/ueditor.parse.min.js'


//引入项目各个页面一级组件
import global_ from './components/Global'  //引用全局变量文件

import adminLogin from './components/adminLogin'  //CMS后台管理系统登录界面

import yjw_cms_system from './admin/yjw_cms_system' 		//CMS后台管理系统主界面
import userShenpiList from './admin/userShenpi/userShenpiList' 		//审批列表
import userShenpiInfo from './admin/userShenpi/userShenpiInfo' 		//审批详情

import platformCompanyManage from './admin/platformCompanyManage/platformCompanyManage' 		//平台企业管理
import platformCompanyInfo from './admin/platformCompanyManage/platformCompanyInfo' 		//平台企业管理

import platformGoodsManage from './admin/platformGoodsManage/platformGoodsManage' 		//平台商品管理
import goodsStockManage from './admin/goodsStockManage/goodsStockManage' 			  	//商品库存管理
import businessRelationManage from './admin/businessRelationManage/businessRelationManage' 			  	//客商关系管理
import orderManage from './admin/orderManage/orderManage' 			  	//订单管理
import storeManage from './admin/storeManage/storeManage' 			  	//仓库管理
import storageRoomManage from './admin/storageRoomManage/storageRoomManage' 			  	//库房管理

import carManage from './admin/carManage/carManage' 			  	//车辆管理
import distributorManage from './admin/distributorManage/distributorManage' 			  	//配送员管理
import newsManage from './admin/newsManage/newsManage' 			  	//资讯管理
import newsAdd from './admin/newsManage/newsAdd' 			  	//新增资讯
import newsUpdate from './admin/newsManage/newsUpdate' 			  	//新增修改

import platformUserMmanage from './admin/userMmanagement/platformUserMmanage' 		//平台用户管理
import roleAuthorityMmanage from './admin/userMmanagement/roleAuthorityMmanage' 		//角色权限管理
import roleAuthorityMmanageUpdate from './admin/userMmanagement/roleAuthorityMmanageUpdate' 		//新增权限列表




Vue.use(VueRouter)
//Vue.use(VueResource)
Vue.use(SIdentify)
Vue.use(ElementUI)

Vue.component('SIdentify', SIdentify)

Vue.prototype.GLOBAL = global_		//挂载到Vue实例上面
Vue.prototype.common = common

Vue.prototype.$axios = axios


//axios.defaults.headers.common['Authorization'] = this.common.SStorage.getItem("saveUserInfo").pwd;

//axios.defaults.baseURL = 'http://192.168.1.2:8080';   //配置axios的全局url  		服务端地址
axios.defaults.baseURL = 'http://116.62.241.107:8080';   //配置axios的全局url  		阿里云服务端地址
//axios.defaults.baseURL = 'http://192.168.1.9:8080';   //配置axios的全局url		开发地址(曹杰)
//axios.defaults.baseURL = 'http://192.168.1.8:8080';   //配置axios的全局url		开发地址(陈晋阳)
//axios.defaults.baseURL = 'http://192.168.1.11:8082';   //配置axios的全局url		开发地址(郑大钊)

let Base64 = require('js-base64').Base64

let router = new VueRouter({
	mode: 'history',
	routes: [
		{
			path: '/',
			component: adminLogin
		},
		{
			path: '/yjw_cms_system',
			component: yjw_cms_system,
			redirect: '/yjw_cms_system/userShenpiList',
			children: [
				{
					path: 'userShenpiList',				//企业平台审核
					component: userShenpiList
				},
				{
					path: 'userShenpiInfo',				//审核详情
					component: userShenpiInfo
				},
				{
					path: 'platformCompanyManage',		//平台企业管理
					component: platformCompanyManage
				},
				{
					path: 'platformCompanyInfo',		//平台企业管理详情
					component: platformCompanyInfo
				},
				{
					path: 'platformGoodsManage',		//平台商品管理
					component: platformGoodsManage
				},	
				{
					path: 'goodsStockManage',			//商品库存管理
					component: goodsStockManage
				},
				{
					path: 'businessRelationManage',			//客商关系管理
					component: businessRelationManage
				},
				{
					path: 'orderManage',			//订单管理
					component: orderManage
				},
				{
					path: 'storeManage',			//仓库管理
					component: storeManage
				},
				{
					path: 'storageRoomManage',			//库房管理
					component: storageRoomManage
				},
				{
					path: 'carManage',			//车辆管理
					component: carManage
				},	
				{
					path: 'distributorManage',			//配送员管理
					component: distributorManage
				},	
				{
					path: 'newsManage',			//资讯管理
					component: newsManage
				},
				{
					path: 'newsAdd',			//新增资讯
					component: newsAdd
				},	
				{
					path: 'newsUpdate',			//新增修改
					component: newsUpdate
				},			
				{
					path: 'platformUserMmanage',		//平台用户管理
					component: platformUserMmanage
				},
				{
					path: 'roleAuthorityMmanage',		//角色权限管理
					component: roleAuthorityMmanage
				},
				{
					path: 'roleAuthorityMmanageUpdate',	//角色权限管理更新
					component: roleAuthorityMmanageUpdate
				},
			]
		}
	]
})



//全局过滤器
Vue.filter('yearToMonth', function (value,format) {	
	if (!value) return ''
	let res = ''
	if(format == 'year-month'){
		res = value.substring(-1,7)  	//**年-**月
	}else if(format == 'day'){
		res = value.substring(8,10)		//**日
	}else if(format == 'year-month-day'){
		res = value.substring(-1,4)+'年'+value.substring(5,7)+'月'+value.substring(8,10)+'日'  	//**年**月**日
	}
  return res
})

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  template: '<adminLogin/>',
  components: { adminLogin }
})

